package com.example.util

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.User
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SessionManager(private val context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("test_mitra_session_prefs", Context.MODE_PRIVATE)

    private val moshi = Moshi.Builder().add(KotlinJsonAdapterFactory()).build()
    private val userAdapter = moshi.adapter(User::class.java)

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _currentLanguage = MutableStateFlow(AppLanguage.GUJARATI)
    val currentLanguage: StateFlow<AppLanguage> = _currentLanguage.asStateFlow()

    init {
        loadSession()
        loadLanguage()
    }

    private fun loadSession() {
        val userJson = prefs.getString(KEY_USER_JSON, null)
        if (!userJson.isNullOrBlank()) {
            try {
                _currentUser.value = userAdapter.fromJson(userJson)
            } catch (_: Exception) {
                _currentUser.value = null
            }
        }
    }

    private fun loadLanguage() {
        val langCode = prefs.getString(KEY_LANGUAGE, AppLanguage.GUJARATI.code)
        _currentLanguage.value = if (langCode == AppLanguage.ENGLISH.code) AppLanguage.ENGLISH else AppLanguage.GUJARATI
    }

    fun saveSession(user: User, sessionToken: String) {
        val json = userAdapter.toJson(user)
        prefs.edit()
            .putString(KEY_USER_JSON, json)
            .putString(KEY_SESSION_TOKEN, sessionToken)
            .putString(KEY_USER_ID, user.id)
            .apply()
        _currentUser.value = user
    }

    fun clearSession() {
        prefs.edit()
            .remove(KEY_USER_JSON)
            .remove(KEY_SESSION_TOKEN)
            .remove(KEY_USER_ID)
            .apply()
        _currentUser.value = null
    }

    fun setLanguage(language: AppLanguage) {
        prefs.edit().putString(KEY_LANGUAGE, language.code).apply()
        _currentLanguage.value = language
    }

    fun getSessionToken(): String? = prefs.getString(KEY_SESSION_TOKEN, null)

    fun getSavedUserId(): String? = prefs.getString(KEY_USER_ID, null)

    companion object {
        private const val KEY_USER_JSON = "key_user_json"
        private const val KEY_SESSION_TOKEN = "key_session_token"
        private const val KEY_USER_ID = "key_user_id"
        private const val KEY_LANGUAGE = "key_language"
    }
}

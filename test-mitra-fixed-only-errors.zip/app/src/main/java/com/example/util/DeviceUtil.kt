package com.example.util

import android.content.Context
import android.content.SharedPreferences
import android.provider.Settings
import java.util.UUID

object DeviceUtil {
    private const val PREFS_NAME = "test_mitra_device_prefs"
    private const val KEY_DEVICE_ID = "unique_device_id"

    fun getDeviceId(context: Context): String {
        val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val savedId = prefs.getString(KEY_DEVICE_ID, null)
        if (!savedId.isNullOrBlank()) {
            return savedId
        }

        // Generate persistent UUID with device Android ID as seed
        val androidId = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID)
        } catch (_: Exception) {
            null
        }

        val generatedId = if (!androidId.isNullOrBlank()) {
            "dev_" + UUID.nameUUIDFromBytes(androidId.toByteArray()).toString().take(16)
        } else {
            "dev_" + UUID.randomUUID().toString().replace("-", "").take(16)
        }

        prefs.edit().putString(KEY_DEVICE_ID, generatedId).apply()
        return generatedId
    }
}

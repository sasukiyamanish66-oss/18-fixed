package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.TestMitraRepository
import com.example.util.SessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AdminViewModel(
    private val repository: TestMitraRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    // Tests State
    private val _tests = MutableStateFlow<List<TestItem>>(emptyList())
    val tests: StateFlow<List<TestItem>> = _tests.asStateFlow()

    private val _isLoadingTests = MutableStateFlow(false)
    val isLoadingTests: StateFlow<Boolean> = _isLoadingTests.asStateFlow()

    // Questions State for Selected Test
    private val _selectedTest = MutableStateFlow<TestItem?>(null)
    val selectedTest: StateFlow<TestItem?> = _selectedTest.asStateFlow()

    private val _questions = MutableStateFlow<List<QuestionItem>>(emptyList())
    val questions: StateFlow<List<QuestionItem>> = _questions.asStateFlow()

    private val _isLoadingQuestions = MutableStateFlow(false)
    val isLoadingQuestions: StateFlow<Boolean> = _isLoadingQuestions.asStateFlow()

    // Users / Students State
    private val _users = MutableStateFlow<List<User>>(emptyList())
    val users: StateFlow<List<User>> = _users.asStateFlow()

    private val _isLoadingUsers = MutableStateFlow(false)
    val isLoadingUsers: StateFlow<Boolean> = _isLoadingUsers.asStateFlow()

    // 5-Hour Results State
    private val _recentResults = MutableStateFlow<List<ResultItem>>(emptyList())
    val recentResults: StateFlow<List<ResultItem>> = _recentResults.asStateFlow()

    private val _isLoadingResults = MutableStateFlow(false)
    val isLoadingResults: StateFlow<Boolean> = _isLoadingResults.asStateFlow()

    // Announcements State
    private val _announcements = MutableStateFlow<List<AnnouncementItem>>(emptyList())
    val announcements: StateFlow<List<AnnouncementItem>> = _announcements.asStateFlow()

    private val _isLoadingAnnouncements = MutableStateFlow(false)
    val isLoadingAnnouncements: StateFlow<Boolean> = _isLoadingAnnouncements.asStateFlow()

    // Status / Message
    private val _snackbarMessage = MutableStateFlow<String?>(null)
    val snackbarMessage: StateFlow<String?> = _snackbarMessage.asStateFlow()

    // ----------------- TESTS -----------------
    fun loadTests() {
        viewModelScope.launch {
            _isLoadingTests.value = true
            val res = repository.getAllTests()
            res.fold(
                onSuccess = { _tests.value = it },
                onFailure = { _snackbarMessage.value = "Failed to load tests: ${it.message}" }
            )
            _isLoadingTests.value = false
        }
    }

    fun createTest(name: String, durationMinutes: Int, isActive: Boolean, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val res = repository.createTest(name, durationMinutes, isActive)
            res.fold(
                onSuccess = {
                    _snackbarMessage.value = "Test created successfully!"
                    loadTests()
                    onSuccess()
                },
                onFailure = { _snackbarMessage.value = "Error creating test: ${it.message}" }
            )
        }
    }

    fun updateTest(testId: String, name: String, durationMinutes: Int, isActive: Boolean, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val res = repository.updateTest(testId, name, durationMinutes, isActive)
            res.fold(
                onSuccess = {
                    _snackbarMessage.value = "Test updated successfully!"
                    loadTests()
                    onSuccess()
                },
                onFailure = { _snackbarMessage.value = "Error updating test: ${it.message}" }
            )
        }
    }

    fun toggleTestStatus(test: TestItem, newIsActive: Boolean, onSuccess: (() -> Unit)? = null) {
        viewModelScope.launch {
            val res = repository.toggleTestStatus(test.id, newIsActive)
            res.fold(
                onSuccess = {
                    _snackbarMessage.value = if (newIsActive) "Test '${test.test_name}' activated!" else "Test '${test.test_name}' deactivated!"
                    loadTests()
                    onSuccess?.invoke()
                },
                onFailure = { _snackbarMessage.value = "Error updating test status: ${it.message}" }
            )
        }
    }

    fun deleteTest(testId: String) {
        viewModelScope.launch {
            val res = repository.deleteTest(testId)
            res.fold(
                onSuccess = {
                    _snackbarMessage.value = "Test deleted."
                    loadTests()
                    if (_selectedTest.value?.id == testId) {
                        _selectedTest.value = null
                        _questions.value = emptyList()
                    }
                },
                onFailure = { _snackbarMessage.value = "Error deleting test: ${it.message}" }
            )
        }
    }

    // ----------------- QUESTIONS -----------------
    fun selectTestForQuestions(test: TestItem) {
        _selectedTest.value = test
        loadQuestions(test.id)
    }

    fun clearSelectedTest() {
        _selectedTest.value = null
        _questions.value = emptyList()
    }

    fun loadQuestions(testId: String) {
        viewModelScope.launch {
            _isLoadingQuestions.value = true
            val res = repository.getQuestionsForTest(testId)
            res.fold(
                onSuccess = { _questions.value = it },
                onFailure = { _snackbarMessage.value = "Failed to load questions: ${it.message}" }
            )
            _isLoadingQuestions.value = false
        }
    }

    fun addQuestion(
        testId: String,
        text: String,
        optA: String,
        optB: String,
        optC: String,
        optD: String,
        correct: String,
        marks: Int = 1,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.createQuestion(testId, text, optA, optB, optC, optD, correct, marks)
            res.fold(
                onSuccess = {
                    _snackbarMessage.value = "Question added successfully!"
                    loadQuestions(testId)
                    onSuccess()
                },
                onFailure = { _snackbarMessage.value = "Error adding question: ${it.message}" }
            )
        }
    }

    fun updateQuestion(
        questionId: String,
        testId: String,
        text: String,
        optA: String,
        optB: String,
        optC: String,
        optD: String,
        correct: String,
        marks: Int = 1,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val res = repository.updateQuestion(questionId, text, optA, optB, optC, optD, correct, marks)
            res.fold(
                onSuccess = {
                    _snackbarMessage.value = "Question updated successfully!"
                    loadQuestions(testId)
                    onSuccess()
                },
                onFailure = { _snackbarMessage.value = "Error updating question: ${it.message}" }
            )
        }
    }

    fun deleteQuestion(questionId: String, testId: String) {
        viewModelScope.launch {
            val res = repository.deleteQuestion(questionId)
            res.fold(
                onSuccess = {
                    _snackbarMessage.value = "Question deleted."
                    loadQuestions(testId)
                },
                onFailure = { _snackbarMessage.value = "Error deleting question: ${it.message}" }
            )
        }
    }

    // ----------------- USERS / STUDENTS -----------------
    fun loadUsers() {
        viewModelScope.launch {
            _isLoadingUsers.value = true
            val res = repository.getAllUsers()
            res.fold(
                onSuccess = { _users.value = it },
                onFailure = { _snackbarMessage.value = "Failed to load users: ${it.message}" }
            )
            _isLoadingUsers.value = false
        }
    }

    fun createUser(name: String, mobile: String, rawPass: String, role: String, onSuccess: () -> Unit) {
        viewModelScope.launch {
            val res = repository.createUser(name, mobile, rawPass, role)
            res.fold(
                onSuccess = {
                    _snackbarMessage.value = "User created successfully!"
                    loadUsers()
                    onSuccess()
                },
                onFailure = { _snackbarMessage.value = "Error creating user: ${it.message}" }
            )
        }
    }

    fun toggleUserStatus(userId: String, currentActive: Boolean) {
        viewModelScope.launch {
            val res = repository.toggleUserStatus(userId, !currentActive)
            res.fold(
                onSuccess = {
                    _snackbarMessage.value = if (!currentActive) "User activated" else "User deactivated"
                    loadUsers()
                },
                onFailure = { _snackbarMessage.value = "Error updating user status: ${it.message}" }
            )
        }
    }

    fun resetUserDevice(userId: String) {
        viewModelScope.launch {
            val res = repository.resetUserDevice(userId)
            res.fold(
                onSuccess = {
                    _snackbarMessage.value = "Device session reset. User can now login on any phone."
                    loadUsers()
                },
                onFailure = { _snackbarMessage.value = "Error resetting device: ${it.message}" }
            )
        }
    }

    fun deleteUser(userId: String) {
        viewModelScope.launch {
            val res = repository.deleteUser(userId)
            res.fold(
                onSuccess = {
                    _snackbarMessage.value = "User deleted."
                    loadUsers()
                },
                onFailure = { _snackbarMessage.value = "Error deleting user: ${it.message}" }
            )
        }
    }

    // ----------------- 5-HOUR RESULTS -----------------
    fun loadRecentResults() {
        viewModelScope.launch {
            _isLoadingResults.value = true
            val res = repository.getRecentAdminResults()
            res.fold(
                onSuccess = { _recentResults.value = it },
                onFailure = { _snackbarMessage.value = "Failed to load results: ${it.message}" }
            )
            _isLoadingResults.value = false
        }
    }

    // ----------------- ANNOUNCEMENTS -----------------
    fun loadAnnouncements() {
        viewModelScope.launch {
            _isLoadingAnnouncements.value = true
            val res = repository.getAnnouncements()
            res.fold(
                onSuccess = { _announcements.value = it },
                onFailure = { _snackbarMessage.value = "Failed to load announcements: ${it.message}" }
            )
            _isLoadingAnnouncements.value = false
        }
    }

    fun createAnnouncement(title: String, message: String, onSuccess: () -> Unit) {
        val user = sessionManager.currentUser.value
        viewModelScope.launch {
            val res = repository.createAnnouncement(title, message, user?.id)
            res.fold(
                onSuccess = {
                    _snackbarMessage.value = "Announcement broadcasted & notifications sent to all active students!"
                    loadAnnouncements()
                    onSuccess()
                },
                onFailure = { _snackbarMessage.value = "Error creating announcement: ${it.message}" }
            )
        }
    }

    fun deleteAnnouncement(announcementId: String) {
        viewModelScope.launch {
            val res = repository.deleteAnnouncement(announcementId)
            res.fold(
                onSuccess = {
                    _snackbarMessage.value = "Announcement deleted."
                    loadAnnouncements()
                },
                onFailure = { _snackbarMessage.value = "Error deleting announcement: ${it.message}" }
            )
        }
    }

    fun clearSnackbar() {
        _snackbarMessage.value = null
    }
}

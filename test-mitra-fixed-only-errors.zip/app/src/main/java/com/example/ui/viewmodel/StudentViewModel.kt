package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.TestMitraRepository
import com.example.util.SessionManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class QuizReviewItem(
    val question: QuestionItem,
    val selectedOption: String?, // "A", "B", "C", "D" or null
    val isCorrect: Boolean,
    val isUnattempted: Boolean
)

data class ActiveQuizState(
    val test: TestItem,
    val questions: List<QuestionItem>,
    val currentIndex: Int = 0,
    val selectedAnswers: Map<String, String> = emptyMap(), // questionId -> option ("A", "B", "C", "D")
    val totalSeconds: Int = 0,
    val remainingSeconds: Int = 0,
    val isSubmitting: Boolean = false,
    val isFinished: Boolean = false
)

class StudentViewModel(
    private val repository: TestMitraRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    // Tests List
    private val _tests = MutableStateFlow<List<TestItem>>(emptyList())
    val tests: StateFlow<List<TestItem>> = _tests.asStateFlow()

    private val _isLoadingTests = MutableStateFlow(false)
    val isLoadingTests: StateFlow<Boolean> = _isLoadingTests.asStateFlow()

    // Active Quiz State
    private val _activeQuiz = MutableStateFlow<ActiveQuizState?>(null)
    val activeQuiz: StateFlow<ActiveQuizState?> = _activeQuiz.asStateFlow()

    private var timerJob: Job? = null

    // Latest Result & Review
    private val _latestResult = MutableStateFlow<ResultItem?>(null)
    val latestResult: StateFlow<ResultItem?> = _latestResult.asStateFlow()

    private val _reviewItems = MutableStateFlow<List<QuizReviewItem>>(emptyList())
    val reviewItems: StateFlow<List<QuizReviewItem>> = _reviewItems.asStateFlow()

    // Results History
    private val _historyResults = MutableStateFlow<List<ResultItem>>(emptyList())
    val historyResults: StateFlow<List<ResultItem>> = _historyResults.asStateFlow()

    private val _isLoadingHistory = MutableStateFlow(false)
    val isLoadingHistory: StateFlow<Boolean> = _isLoadingHistory.asStateFlow()

    // Announcements & Notifications
    private val _announcements = MutableStateFlow<List<AnnouncementItem>>(emptyList())
    val announcements: StateFlow<List<AnnouncementItem>> = _announcements.asStateFlow()

    private val _notifications = MutableStateFlow<List<NotificationItem>>(emptyList())
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    private val _unreadCount = MutableStateFlow(0)
    val unreadCount: StateFlow<Int> = _unreadCount.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    fun loadActiveTests() {
        viewModelScope.launch {
            _isLoadingTests.value = true
            _errorMessage.value = null
            val res = repository.getActiveTests()
            res.fold(
                onSuccess = { list ->
                    _tests.value = list
                },
                onFailure = { error ->
                    _errorMessage.value = error.message ?: "Failed to load tests"
                }
            )
            _isLoadingTests.value = false
        }
    }

    fun startTest(test: TestItem, onReady: () -> Unit) {
        viewModelScope.launch {
            _errorMessage.value = null
            val res = repository.getQuestionsForTest(test.id)
            res.fold(
                onSuccess = { qList ->
                    if (qList.isEmpty()) {
                        _errorMessage.value = "This test has no questions yet."
                        return@launch
                    }
                    val totalSec = test.duration * 60
                    _activeQuiz.value = ActiveQuizState(
                        test = test,
                        questions = qList,
                        currentIndex = 0,
                        selectedAnswers = emptyMap(),
                        totalSeconds = totalSec,
                        remainingSeconds = totalSec
                    )
                    startTimer()
                    onReady()
                },
                onFailure = { error ->
                    _errorMessage.value = error.message ?: "Failed to load questions"
                }
            )
        }
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val current = _activeQuiz.value ?: break
                if (current.remainingSeconds <= 1) {
                    _activeQuiz.value = current.copy(remainingSeconds = 0)
                    submitQuiz()
                    break
                } else {
                    _activeQuiz.value = current.copy(remainingSeconds = current.remainingSeconds - 1)
                }
            }
        }
    }

    fun selectAnswer(questionId: String, option: String) {
        val current = _activeQuiz.value ?: return
        val updated = current.selectedAnswers.toMutableMap()
        if (updated[questionId] == option) {
            updated.remove(questionId) // toggle off
        } else {
            updated[questionId] = option
        }
        _activeQuiz.value = current.copy(selectedAnswers = updated)
    }

    fun clearAnswer(questionId: String) {
        val current = _activeQuiz.value ?: return
        val updated = current.selectedAnswers.toMutableMap()
        updated.remove(questionId)
        _activeQuiz.value = current.copy(selectedAnswers = updated)
    }

    fun setCurrentQuestionIndex(index: Int) {
        val current = _activeQuiz.value ?: return
        if (index in current.questions.indices) {
            _activeQuiz.value = current.copy(currentIndex = index)
        }
    }

    fun submitQuiz(onComplete: (() -> Unit)? = null) {
        timerJob?.cancel()
        val current = _activeQuiz.value ?: return
        val user = sessionManager.currentUser.value ?: return

        _activeQuiz.value = current.copy(isSubmitting = true)

        viewModelScope.launch {
            val questions = current.questions
            val answers = current.selectedAnswers

            var correctCount = 0
            var wrongCount = 0
            var unattemptedCount = 0

            val reviews = questions.map { q ->
                val selected = answers[q.id]
                val isUnattempted = selected.isNullOrBlank()
                val isCorrect = !isUnattempted && selected.equals(q.correct_option, ignoreCase = true)
                if (isCorrect) {
                    correctCount++
                } else if (isUnattempted) {
                    unattemptedCount++
                } else {
                    wrongCount++
                }
                QuizReviewItem(
                    question = q,
                    selectedOption = selected,
                    isCorrect = isCorrect,
                    isUnattempted = isUnattempted
                )
            }

            val total = questions.size
            val percentage = if (total > 0) (correctCount.toDouble() / total) * 100.0 else 0.0

            val result = repository.submitQuizResult(
                userId = user.id,
                testId = current.test.id,
                totalQuestions = total,
                correctAnswers = correctCount,
                wrongAnswers = wrongCount,
                unattempted = unattemptedCount,
                percentage = Math.round(percentage * 100.0) / 100.0
            )

            result.fold(
                onSuccess = { savedResult ->
                    _latestResult.value = savedResult.copy(test_name = current.test.test_name)
                    _reviewItems.value = reviews
                    _activeQuiz.value = current.copy(isSubmitting = false, isFinished = true)
                    onComplete?.invoke()
                },
                onFailure = { error ->
                    // If network issue on save, construct client result
                    val clientResult = ResultItem(
                        id = "temp_${System.currentTimeMillis()}",
                        user_id = user.id,
                        test_id = current.test.id,
                        total_questions = total,
                        correct_answers = correctCount,
                        wrong_answers = wrongCount,
                        unattempted = unattemptedCount,
                        percentage = Math.round(percentage * 100.0) / 100.0,
                        attempt_number = 1,
                        submitted_at = "Just now",
                        test_name = current.test.test_name
                    )
                    _latestResult.value = clientResult
                    _reviewItems.value = reviews
                    _activeQuiz.value = current.copy(isSubmitting = false, isFinished = true)
                    onComplete?.invoke()
                }
            )
        }
    }

    fun loadUserHistory() {
        val user = sessionManager.currentUser.value ?: return
        viewModelScope.launch {
            _isLoadingHistory.value = true
            val res = repository.getUserResults(user.id)
            res.fold(
                onSuccess = { list ->
                    _historyResults.value = list
                },
                onFailure = { error ->
                    _errorMessage.value = error.message
                }
            )
            _isLoadingHistory.value = false
        }
    }

    fun loadAnnouncementsAndNotifications() {
        val user = sessionManager.currentUser.value ?: return
        viewModelScope.launch {
            val aRes = repository.getAnnouncements()
            aRes.onSuccess { _announcements.value = it }

            val nRes = repository.getNotificationsForUser(user.id)
            nRes.onSuccess { list ->
                _notifications.value = list
                _unreadCount.value = list.count { !it.is_read }
            }
        }
    }

    fun markNotificationRead(item: NotificationItem) {
        viewModelScope.launch {
            repository.markNotificationRead(item.id)
            val updated = _notifications.value.map {
                if (it.id == item.id) it.copy(is_read = true) else it
            }
            _notifications.value = updated
            _unreadCount.value = updated.count { !it.is_read }
        }
    }

    fun clearActiveQuiz() {
        timerJob?.cancel()
        _activeQuiz.value = null
    }

    fun clearError() {
        _errorMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}

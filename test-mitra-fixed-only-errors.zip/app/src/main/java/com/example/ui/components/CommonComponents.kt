package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.*
import com.example.util.AppLanguage
import com.example.util.LanguageStrings

@Composable
fun OfflineNoticeBanner(
    isOnline: Boolean,
    currentLanguage: AppLanguage,
    onRetry: () -> Unit
) {
    AnimatedVisibility(visible = !isOnline) {
        Surface(
            color = ErrorRed,
            contentColor = Color.White,
            modifier = Modifier.fillMaxWidth().testTag("offline_banner")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.WifiOff,
                        contentDescription = "No Internet",
                        modifier = Modifier.size(20.dp),
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = LanguageStrings.get("error_no_internet", currentLanguage),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )
                }
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White,
                        contentColor = ErrorRed
                    ),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                    modifier = Modifier.testTag("retry_network_button")
                ) {
                    Text(
                        text = LanguageStrings.get("retry", currentLanguage),
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}

@Composable
fun LanguageSwitchButton(
    currentLanguage: AppLanguage,
    onLanguageSelected: (AppLanguage) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Box(modifier = modifier) {
        FilledTonalButton(
            onClick = { expanded = true },
            shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.filledTonalButtonColors(
                containerColor = PrimaryContainerBlue,
                contentColor = PrimaryBlue
            ),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            modifier = Modifier.testTag("language_switch_button")
        ) {
            Icon(
                imageVector = Icons.Default.Language,
                contentDescription = "Change Language",
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (currentLanguage == AppLanguage.GUJARATI) "ગુજરાતી" else "English",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold
            )
        }

        DropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            DropdownMenuItem(
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("ગુજરાતી (Gujarati)", fontWeight = if (currentLanguage == AppLanguage.GUJARATI) FontWeight.Bold else FontWeight.Normal)
                        if (currentLanguage == AppLanguage.GUJARATI) {
                            Spacer(Modifier.width(8.dp))
                            Icon(Icons.Default.Check, contentDescription = null, tint = PrimaryGreen, modifier = Modifier.size(16.dp))
                        }
                    }
                },
                onClick = {
                    onLanguageSelected(AppLanguage.GUJARATI)
                    expanded = false
                }
            )
            DropdownMenuItem(
                text = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("English", fontWeight = if (currentLanguage == AppLanguage.ENGLISH) FontWeight.Bold else FontWeight.Normal)
                        if (currentLanguage == AppLanguage.ENGLISH) {
                            Spacer(Modifier.width(8.dp))
                            Icon(Icons.Default.Check, contentDescription = null, tint = PrimaryGreen, modifier = Modifier.size(16.dp))
                        }
                    }
                },
                onClick = {
                    onLanguageSelected(AppLanguage.ENGLISH)
                    expanded = false
                }
            )
        }
    }
}

@Composable
fun AppLogoHeader(
    modifier: Modifier = Modifier,
    size: Int = 100
) {
    Image(
        painter = painterResource(id = R.drawable.test_mitra_logo),
        contentDescription = "TEST MITRA Logo",
        contentScale = ContentScale.Fit,
        modifier = modifier
            .size(size.dp)
            .clip(CircleShape)
            .background(Color.White)
    )
}

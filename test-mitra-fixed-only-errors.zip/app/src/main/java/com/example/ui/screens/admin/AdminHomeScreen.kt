package com.example.ui.screens.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.ui.components.LanguageSwitchButton
import com.example.ui.theme.*
import com.example.ui.viewmodel.AdminViewModel
import com.example.ui.viewmodel.AuthViewModel
import com.example.util.AppLanguage
import com.example.util.LanguageStrings
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminHomeScreen(
    user: User,
    authViewModel: AuthViewModel,
    adminViewModel: AdminViewModel,
    onLogout: () -> Unit
) {
    val currentLanguage by authViewModel.currentLanguage.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) }
    var showLogoutDialog by remember { mutableStateOf(false) }

    val tests by adminViewModel.tests.collectAsState()
    val isLoadingTests by adminViewModel.isLoadingTests.collectAsState()
    val selectedTest by adminViewModel.selectedTest.collectAsState()
    val questions by adminViewModel.questions.collectAsState()
    val isLoadingQuestions by adminViewModel.isLoadingQuestions.collectAsState()
    val users by adminViewModel.users.collectAsState()
    val isLoadingUsers by adminViewModel.isLoadingUsers.collectAsState()
    val recentResults by adminViewModel.recentResults.collectAsState()
    val isLoadingResults by adminViewModel.isLoadingResults.collectAsState()
    val announcements by adminViewModel.announcements.collectAsState()
    val isLoadingAnnouncements by adminViewModel.isLoadingAnnouncements.collectAsState()
    val snackbarMsg by adminViewModel.snackbarMessage.collectAsState()

    // Dialog states
    var showAddTestDialog by remember { mutableStateOf(false) }
    var testToEdit by remember { mutableStateOf<TestItem?>(null) }
    var testToToggleActive by remember { mutableStateOf<Pair<TestItem, Boolean>?>(null) }
    var testToDelete by remember { mutableStateOf<TestItem?>(null) }
    var showAddQuestionDialog by remember { mutableStateOf(false) }
    var questionToEdit by remember { mutableStateOf<QuestionItem?>(null) }
    var showAddUserDialog by remember { mutableStateOf(false) }
    var showAddAnnouncementDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        adminViewModel.loadTests()
        adminViewModel.loadUsers()
        adminViewModel.loadRecentResults()
        adminViewModel.loadAnnouncements()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Image(
                            painter = painterResource(id = R.drawable.test_mitra_logo),
                            contentDescription = "App Logo",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = LanguageStrings.get("app_name", currentLanguage),
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryBlue
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (user.role == "Admin") PrimaryContainerBlue else SecondaryContainerGreen
                                ) {
                                    Text(
                                        text = user.role,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (user.role == "Admin") PrimaryBlue else OnSecondaryContainerGreen,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = user.name,
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                },
                actions = {
                    LanguageSwitchButton(
                        currentLanguage = currentLanguage,
                        onLanguageSelected = { authViewModel.setLanguage(it) },
                        modifier = Modifier.padding(end = 4.dp)
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = Color.White,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = {
                        selectedTab = 0
                        adminViewModel.clearSelectedTest()
                        adminViewModel.loadTests()
                    },
                    icon = { Icon(Icons.Default.LibraryBooks, contentDescription = "Tests") },
                    label = { Text(LanguageStrings.get("manage_tests", currentLanguage), maxLines = 1) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PrimaryBlue,
                        indicatorColor = PrimaryContainerBlue
                    ),
                    modifier = Modifier.testTag("admin_nav_tests")
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = {
                        selectedTab = 1
                        adminViewModel.loadRecentResults()
                    },
                    icon = { Icon(Icons.Default.Analytics, contentDescription = "5h Results") },
                    label = { Text("5h Results", maxLines = 1) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PrimaryBlue,
                        indicatorColor = PrimaryContainerBlue
                    ),
                    modifier = Modifier.testTag("admin_nav_results")
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = {
                        selectedTab = 2
                        adminViewModel.loadUsers()
                    },
                    icon = { Icon(Icons.Default.People, contentDescription = "Users") },
                    label = { Text(LanguageStrings.get("manage_students", currentLanguage), maxLines = 1) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PrimaryBlue,
                        indicatorColor = PrimaryContainerBlue
                    ),
                    modifier = Modifier.testTag("admin_nav_users")
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = {
                        selectedTab = 3
                        adminViewModel.loadAnnouncements()
                    },
                    icon = { Icon(Icons.Default.Campaign, contentDescription = "Announcements") },
                    label = { Text(LanguageStrings.get("announcements", currentLanguage), maxLines = 1) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PrimaryBlue,
                        indicatorColor = PrimaryContainerBlue
                    ),
                    modifier = Modifier.testTag("admin_nav_announcements")
                )
                NavigationBarItem(
                    selected = selectedTab == 4,
                    onClick = { selectedTab = 4 },
                    icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                    label = { Text(LanguageStrings.get("profile_tab", currentLanguage), maxLines = 1) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = PrimaryBlue,
                        indicatorColor = PrimaryContainerBlue
                    ),
                    modifier = Modifier.testTag("admin_nav_profile")
                )
            }
        },
        floatingActionButton = {
            when (selectedTab) {
                0 -> {
                    if (selectedTest == null) {
                        FloatingActionButton(
                            onClick = { showAddTestDialog = true },
                            containerColor = PrimaryBlue,
                            contentColor = Color.White,
                            modifier = Modifier.testTag("add_test_fab")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add Test")
                        }
                    } else {
                        FloatingActionButton(
                            onClick = { showAddQuestionDialog = true },
                            containerColor = PrimaryGreen,
                            contentColor = Color.White,
                            modifier = Modifier.testTag("add_question_fab")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Add Question")
                        }
                    }
                }
                2 -> {
                    FloatingActionButton(
                        onClick = { showAddUserDialog = true },
                        containerColor = PrimaryBlue,
                        contentColor = Color.White,
                        modifier = Modifier.testTag("add_user_fab")
                    ) {
                        Icon(Icons.Default.PersonAdd, contentDescription = "Add User")
                    }
                }
                3 -> {
                    FloatingActionButton(
                        onClick = { showAddAnnouncementDialog = true },
                        containerColor = PrimaryGreen,
                        contentColor = Color.White,
                        modifier = Modifier.testTag("add_announcement_fab")
                    ) {
                        Icon(Icons.Default.AddAlert, contentDescription = "Create Announcement")
                    }
                }
            }
        },
        containerColor = AppBackgroundLight
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("admin_home_screen")
        ) {
            when (selectedTab) {
                0 -> {
                    if (selectedTest == null) {
                        AdminTestsListTab(
                            tests = tests,
                            isLoading = isLoadingTests,
                            currentLanguage = currentLanguage,
                            onSelectTest = { adminViewModel.selectTestForQuestions(it) },
                            onEditTest = { testToEdit = it },
                            onToggleActive = { test, newStatus ->
                                testToToggleActive = Pair(test, newStatus)
                            },
                            onDeleteTest = { testToDelete = it },
                            onRefresh = { adminViewModel.loadTests() }
                        )
                    } else {
                        AdminQuestionsListTab(
                            test = selectedTest!!,
                            questions = questions,
                            isLoading = isLoadingQuestions,
                            currentLanguage = currentLanguage,
                            onBack = { adminViewModel.clearSelectedTest() },
                            onEditQuestion = { questionToEdit = it },
                            onDeleteQuestion = { adminViewModel.deleteQuestion(it.id, selectedTest!!.id) }
                        )
                    }
                }
                1 -> AdminRecentResultsTab(
                    results = recentResults,
                    isLoading = isLoadingResults,
                    currentLanguage = currentLanguage,
                    onRefresh = { adminViewModel.loadRecentResults() }
                )
                2 -> AdminUsersTab(
                    users = users,
                    isLoading = isLoadingUsers,
                    currentLanguage = currentLanguage,
                    onToggleActive = { adminViewModel.toggleUserStatus(it.id, it.is_active) },
                    onResetDevice = { adminViewModel.resetUserDevice(it.id) },
                    onDeleteUser = { adminViewModel.deleteUser(it.id) },
                    onRefresh = { adminViewModel.loadUsers() }
                )
                3 -> AdminAnnouncementsTab(
                    announcements = announcements,
                    isLoading = isLoadingAnnouncements,
                    currentLanguage = currentLanguage,
                    onDelete = { adminViewModel.deleteAnnouncement(it.id) },
                    onRefresh = { adminViewModel.loadAnnouncements() }
                )
                4 -> AdminProfileTab(
                    user = user,
                    currentLanguage = currentLanguage,
                    onLogoutClick = { showLogoutDialog = true }
                )
            }

            if (snackbarMsg != null) {
                Snackbar(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp),
                    action = {
                        TextButton(onClick = { adminViewModel.clearSnackbar() }) {
                            Text("OK", color = Color.White)
                        }
                    }
                ) {
                    Text(snackbarMsg ?: "")
                }
            }
        }
    }

    // Add / Edit Test Dialog
    if (showAddTestDialog || testToEdit != null) {
        val editing = testToEdit
        AddEditTestDialog(
            initialTest = editing,
            currentLanguage = currentLanguage,
            onDismiss = {
                showAddTestDialog = false
                testToEdit = null
            },
            onSave = { name, duration, isActive ->
                if (editing == null) {
                    adminViewModel.createTest(name, duration, isActive) {
                        showAddTestDialog = false
                    }
                } else {
                    adminViewModel.updateTest(editing.id, name, duration, isActive) {
                        testToEdit = null
                    }
                }
            }
        )
    }

    // Add / Edit Question Dialog
    if ((showAddQuestionDialog || questionToEdit != null) && selectedTest != null) {
        val editingQ = questionToEdit
        val currentT = selectedTest!!
        AddEditQuestionDialog(
            initialQuestion = editingQ,
            currentLanguage = currentLanguage,
            onDismiss = {
                showAddQuestionDialog = false
                questionToEdit = null
            },
            onSave = { text, a, b, c, d, correct, marks ->
                if (editingQ == null) {
                    adminViewModel.addQuestion(currentT.id, text, a, b, c, d, correct, marks) {
                        showAddQuestionDialog = false
                    }
                } else {
                    adminViewModel.updateQuestion(editingQ.id, currentT.id, text, a, b, c, d, correct, marks) {
                        questionToEdit = null
                    }
                }
            }
        )
    }

    // Add User Dialog
    if (showAddUserDialog) {
        AddUserDialog(
            currentLanguage = currentLanguage,
            onDismiss = { showAddUserDialog = false },
            onSave = { name, mobile, pass, role ->
                adminViewModel.createUser(name, mobile, pass, role) {
                    showAddUserDialog = false
                }
            }
        )
    }

    // Add Announcement Dialog
    if (showAddAnnouncementDialog) {
        AddAnnouncementDialog(
            currentLanguage = currentLanguage,
            onDismiss = { showAddAnnouncementDialog = false },
            onSave = { title, msg ->
                adminViewModel.createAnnouncement(title, msg) {
                    showAddAnnouncementDialog = false
                }
            }
        )
    }

    // Delete Test Dialog
    if (testToDelete != null) {
        val targetTest = testToDelete!!
        AlertDialog(
            onDismissRequest = { testToDelete = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.DeleteForever,
                    contentDescription = null,
                    tint = ErrorRed,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = LanguageStrings.get("delete_test", currentLanguage),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text("Are you sure you want to permanently delete \"${targetTest.test_name}\" and all its questions? This action cannot be undone.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        adminViewModel.deleteTest(targetTest.id)
                        testToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text(LanguageStrings.get("delete", currentLanguage), fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { testToDelete = null }) {
                    Text(LanguageStrings.get("cancel", currentLanguage))
                }
            }
        )
    }

    // Activate / Deactivate Test Confirmation Dialog
    if (testToToggleActive != null) {
        val (targetTest, newStatus) = testToToggleActive!!
        val isActivating = newStatus
        AlertDialog(
            onDismissRequest = { testToToggleActive = null },
            icon = {
                Icon(
                    imageVector = if (isActivating) Icons.Default.CheckCircle else Icons.Default.PauseCircleFilled,
                    contentDescription = null,
                    tint = if (isActivating) PrimaryGreen else WarningAmber,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = if (isActivating) LanguageStrings.get("activate_test", currentLanguage) else LanguageStrings.get("deactivate_test", currentLanguage),
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column {
                    Text(
                        text = targetTest.test_name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = PrimaryBlue
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isActivating) {
                            LanguageStrings.get("activate_test_confirm", currentLanguage)
                        } else {
                            LanguageStrings.get("deactivate_test_confirm", currentLanguage)
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        adminViewModel.toggleTestStatus(targetTest, newStatus)
                        testToToggleActive = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isActivating) PrimaryGreen else ErrorRed
                    )
                ) {
                    Text(
                        text = if (isActivating) LanguageStrings.get("activate", currentLanguage) else LanguageStrings.get("deactivate", currentLanguage),
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { testToToggleActive = null }) {
                    Text(LanguageStrings.get("cancel", currentLanguage))
                }
            }
        )
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text(LanguageStrings.get("logout", currentLanguage)) },
            text = { Text(LanguageStrings.get("logout_confirm", currentLanguage)) },
            confirmButton = {
                Button(
                    onClick = {
                        showLogoutDialog = false
                        authViewModel.logout(onLogout)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text(LanguageStrings.get("logout", currentLanguage))
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) {
                    Text(LanguageStrings.get("cancel", currentLanguage))
                }
            }
        )
    }
}

// ----------------- ADMIN SUB-TABS -----------------

@Composable
fun AdminTestsListTab(
    tests: List<TestItem>,
    isLoading: Boolean,
    currentLanguage: AppLanguage,
    onSelectTest: (TestItem) -> Unit,
    onEditTest: (TestItem) -> Unit,
    onToggleActive: (TestItem, Boolean) -> Unit,
    onDeleteTest: (TestItem) -> Unit,
    onRefresh: () -> Unit
) {
    if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = PrimaryBlue)
        }
        return
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = LanguageStrings.get("test_management", currentLanguage),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryBlue
                    )
                    Text(
                        text = "${tests.size} ${if (tests.size == 1) "Test" else "Tests"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                IconButton(
                    onClick = onRefresh,
                    modifier = Modifier.background(PrimaryContainerBlue.copy(alpha = 0.4f), CircleShape)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = PrimaryBlue)
                }
            }
        }

        if (tests.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, AppBorderLight),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("No tests created yet. Tap '+' to create your first test.", color = TextSecondary)
                    }
                }
            }
        } else {
            items(tests, key = { it.id }) { test ->
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    border = BorderStroke(1.dp, if (test.is_active) PrimaryBlueLight.copy(alpha = 0.25f) else Color(0xFFE2E8F0)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("admin_test_card_${test.id}")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Title & Status Header
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = test.test_name,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(end = 8.dp)
                            )
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (test.is_active) Color(0xFFDCFCE7) else Color(0xFFFEE2E2),
                                border = BorderStroke(1.dp, if (test.is_active) Color(0xFF86EFAC) else Color(0xFFFCA5A5))
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .background(
                                                color = if (test.is_active) PrimaryGreen else ErrorRed,
                                                shape = CircleShape
                                            )
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (test.is_active) LanguageStrings.get("active", currentLanguage) else LanguageStrings.get("inactive", currentLanguage),
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (test.is_active) Color(0xFF15803D) else Color(0xFFB91C1C)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Duration Chip
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = PrimaryContainerBlue.copy(alpha = 0.5f)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Timer,
                                        contentDescription = null,
                                        tint = PrimaryBlue,
                                        modifier = Modifier.size(15.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${test.duration} ${LanguageStrings.get("minutes", currentLanguage)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = PrimaryBlue
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        HorizontalDivider(color = Color(0xFFF1F5F9), thickness = 1.dp)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Action Buttons Row 1: Manage Questions & Edit Button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Button(
                                onClick = { onSelectTest(test) },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .testTag("manage_questions_btn_${test.id}")
                            ) {
                                Icon(Icons.Default.FormatListBulleted, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = LanguageStrings.get("manage_questions", currentLanguage),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1
                                )
                            }

                            OutlinedButton(
                                onClick = { onEditTest(test) },
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, PrimaryBlue.copy(alpha = 0.4f)),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryBlue),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                modifier = Modifier
                                    .height(42.dp)
                                    .testTag("edit_test_btn_${test.id}")
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(15.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = LanguageStrings.get("edit_test", currentLanguage),
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Action Buttons Row 2: Activate / Deactivate Button & Delete Button
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            if (test.is_active) {
                                // Deactivate Button (Prominent, Responsive)
                                OutlinedButton(
                                    onClick = { onToggleActive(test, false) },
                                    shape = RoundedCornerShape(10.dp),
                                    border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                                    colors = ButtonDefaults.outlinedButtonColors(
                                        containerColor = Color(0xFFFEF2F2),
                                        contentColor = Color(0xFFDC2626)
                                    ),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(42.dp)
                                        .testTag("deactivate_test_btn_${test.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PauseCircleOutline,
                                        contentDescription = null,
                                        tint = Color(0xFFDC2626),
                                        modifier = Modifier.size(17.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = LanguageStrings.get("deactivate", currentLanguage),
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            } else {
                                // Activate Button (Prominent, Responsive)
                                Button(
                                    onClick = { onToggleActive(test, true) },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = PrimaryGreen,
                                        contentColor = Color.White
                                    ),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(42.dp)
                                        .testTag("activate_test_btn_${test.id}")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.PlayCircleOutline,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(17.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = LanguageStrings.get("activate", currentLanguage),
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            IconButton(
                                onClick = { onDeleteTest(test) },
                                modifier = Modifier
                                    .size(42.dp)
                                    .background(Color(0xFFF8FAFC), shape = RoundedCornerShape(10.dp))
                                    .testTag("delete_test_btn_${test.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DeleteOutline,
                                    contentDescription = "Delete Test",
                                    tint = TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminQuestionsListTab(
    test: TestItem,
    questions: List<QuestionItem>,
    isLoading: Boolean,
    currentLanguage: AppLanguage,
    onBack: () -> Unit,
    onEditQuestion: (QuestionItem) -> Unit,
    onDeleteQuestion: (QuestionItem) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PrimaryBlue)
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = test.test_name,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryBlue
                    )
                    Text(
                        text = "${questions.size} ${LanguageStrings.get("questions", currentLanguage)}",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        if (isLoading) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PrimaryBlue)
                }
            }
        } else if (questions.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("No questions in this test yet. Tap '+' to add MCQ questions.", color = TextSecondary)
                    }
                }
            }
        } else {
            items(questions, key = { it.id }) { q ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = q.question_text,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            Row {
                                IconButton(onClick = { onEditQuestion(q) }, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Default.Edit, contentDescription = "Edit", tint = PrimaryBlue, modifier = Modifier.size(18.dp))
                                }
                                IconButton(onClick = { onDeleteQuestion(q) }, modifier = Modifier.size(32.dp)) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = ErrorRed, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            QuestionOptionBadge(key = "A", text = q.option_a, isCorrect = q.correct_option.equals("A", ignoreCase = true))
                            QuestionOptionBadge(key = "B", text = q.option_b, isCorrect = q.correct_option.equals("B", ignoreCase = true))
                            QuestionOptionBadge(key = "C", text = q.option_c, isCorrect = q.correct_option.equals("C", ignoreCase = true))
                            QuestionOptionBadge(key = "D", text = q.option_d, isCorrect = q.correct_option.equals("D", ignoreCase = true))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuestionOptionBadge(key: String, text: String, isCorrect: Boolean) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = if (isCorrect) Color(0xFFE8F5E9) else AppSurfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "($key) $text",
                style = MaterialTheme.typography.bodySmall,
                color = if (isCorrect) PrimaryGreen else TextPrimary,
                fontWeight = if (isCorrect) FontWeight.Bold else FontWeight.Normal,
                modifier = Modifier.weight(1f)
            )
            if (isCorrect) {
                Text(
                    text = "✓ Correct",
                    style = MaterialTheme.typography.labelSmall,
                    color = SuccessGreen,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun AdminRecentResultsTab(
    results: List<ResultItem>,
    isLoading: Boolean,
    currentLanguage: AppLanguage,
    onRefresh: () -> Unit
) {
    val isoParser = remember {
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US).apply {
            timeZone = TimeZone.getTimeZone("UTC")
        }
    }

    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = LanguageStrings.get("student_results", currentLanguage),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryBlue
                    )
                    IconButton(onClick = onRefresh) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = PrimaryBlue)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = PrimaryContainerBlue.copy(alpha = 0.6f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = LanguageStrings.get("five_hour_rule_note", currentLanguage),
                            style = MaterialTheme.typography.bodySmall,
                            color = PrimaryBlue
                        )
                    }
                }
            }
        }

        if (isLoading) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PrimaryBlue)
                }
            }
        } else if (results.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("No student results submitted in the last 5 hours.", color = TextSecondary)
                    }
                }
            }
        } else {
            items(results, key = { it.id }) { item ->
                // Calculate remaining time within 5h window
                val remainingMins = remember(item.submitted_at) {
                    try {
                        val cleanDateStr = item.submitted_at.substringBefore(".").substringBefore("+").substringBefore("Z")
                        val submittedDate = isoParser.parse(cleanDateStr)
                        if (submittedDate != null) {
                            val elapsedMs = System.currentTimeMillis() - submittedDate.time
                            val remainingMs = (5 * 3600 * 1000) - elapsedMs
                            (remainingMs / (60 * 1000)).coerceAtLeast(0).toInt()
                        } else 300
                    } catch (_: Exception) {
                        300
                    }
                }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.user_name ?: "Student",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                if (!item.student_mobile.isNullOrBlank()) {
                                    Text(
                                        text = item.student_mobile,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (item.percentage >= 50.0) SecondaryContainerGreen else Color(0xFFFFEBEE)
                            ) {
                                Text(
                                    text = "${item.percentage}%",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.percentage >= 50.0) PrimaryGreen else ErrorRed,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = "${LanguageStrings.get("test_name", currentLanguage)}: ${item.test_name ?: "Test"}",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = PrimaryBlue
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Score: ${item.correct_answers}/${item.total_questions} (Attempt #${item.attempt_number})",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFFFFF3CD)
                            ) {
                                Text(
                                    text = "Visible for ${remainingMins / 60}h ${remainingMins % 60}m",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF856404),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminUsersTab(
    users: List<User>,
    isLoading: Boolean,
    currentLanguage: AppLanguage,
    onToggleActive: (User) -> Unit,
    onResetDevice: (User) -> Unit,
    onDeleteUser: (User) -> Unit,
    onRefresh: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = LanguageStrings.get("manage_students", currentLanguage),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryBlue
                )
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = PrimaryBlue)
                }
            }
        }

        if (isLoading) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PrimaryBlue)
                }
            }
        } else {
            items(users, key = { it.id }) { u ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = u.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = u.mobile_number,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondary
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = when (u.role) {
                                    "Admin" -> PrimaryContainerBlue
                                    "Teacher" -> SecondaryContainerGreen
                                    else -> AppSurfaceVariant
                                }
                            ) {
                                Text(
                                    text = u.role,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = when (u.role) {
                                        "Admin" -> PrimaryBlue
                                        "Teacher" -> OnSecondaryContainerGreen
                                        else -> TextPrimary
                                    },
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = CircleShape,
                                color = if (u.is_active) SuccessGreen else ErrorRed,
                                modifier = Modifier.size(8.dp)
                            ) {}
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (u.is_active) LanguageStrings.get("active", currentLanguage) else LanguageStrings.get("inactive", currentLanguage),
                                style = MaterialTheme.typography.bodySmall,
                                color = if (u.is_active) SuccessGreen else ErrorRed,
                                fontWeight = FontWeight.Medium
                            )

                            if (!u.active_device_id.isNullOrBlank()) {
                                Spacer(modifier = Modifier.width(12.dp))
                                Icon(Icons.Default.Smartphone, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Device Locked", style = MaterialTheme.typography.bodySmall, color = PrimaryBlue)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            if (!u.active_device_id.isNullOrBlank()) {
                                OutlinedButton(
                                    onClick = { onResetDevice(u) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = WarningAmber),
                                    border = BorderStroke(1.dp, WarningAmber),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.PhoneAndroid, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(LanguageStrings.get("reset_device", currentLanguage), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }
                            }

                            FilledTonalButton(
                                onClick = { onToggleActive(u) },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = if (u.is_active) "Deactivate" else "Activate",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            if (u.role != "Admin") {
                                IconButton(onClick = { onDeleteUser(u) }) {
                                    Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = ErrorRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AdminAnnouncementsTab(
    announcements: List<AnnouncementItem>,
    isLoading: Boolean,
    currentLanguage: AppLanguage,
    onDelete: (AnnouncementItem) -> Unit,
    onRefresh: () -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = LanguageStrings.get("announcements", currentLanguage),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryBlue
                )
                IconButton(onClick = onRefresh) {
                    Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = PrimaryBlue)
                }
            }
        }

        if (isLoading) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = PrimaryBlue)
                }
            }
        } else if (announcements.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(32.dp), contentAlignment = Alignment.Center) {
                        Text("No announcements broadcasted yet. Tap '+' to create.", color = TextSecondary)
                    }
                }
            }
        } else {
            items(announcements, key = { it.id }) { ann ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = ann.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(onClick = { onDelete(ann) }) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = ErrorRed)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = ann.message,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            lineHeight = 20.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AdminProfileTab(
    user: User,
    currentLanguage: AppLanguage,
    onLogoutClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            shape = CircleShape,
            color = PrimaryContainerBlue,
            modifier = Modifier.size(90.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = Icons.Default.AdminPanelSettings,
                    contentDescription = null,
                    tint = PrimaryBlue,
                    modifier = Modifier.size(48.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = user.name,
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = TextPrimary
        )

        Spacer(modifier = Modifier.height(4.dp))

        Surface(
            shape = RoundedCornerShape(12.dp),
            color = PrimaryContainerBlue
        ) {
            Text(
                text = "${user.role} Account",
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = PrimaryBlue,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Phone, contentDescription = null, tint = PrimaryBlue, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(LanguageStrings.get("mobile", currentLanguage), style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Text(user.mobile_number, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = AppBorderLight)

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CloudQueue, contentDescription = null, tint = PrimaryGreen, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("Database Engine", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
                        Text("Supabase Online (PostgreSQL)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onLogoutClick,
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = ErrorRed, contentColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("admin_logout_button")
        ) {
            Icon(Icons.Default.Logout, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text(LanguageStrings.get("logout", currentLanguage), fontWeight = FontWeight.Bold)
        }
    }
}

// ----------------- DIALOGS -----------------

@Composable
fun AddEditTestDialog(
    initialTest: TestItem?,
    currentLanguage: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (String, Int, Boolean) -> Unit
) {
    var name by remember { mutableStateOf(initialTest?.test_name ?: "") }
    var durationStr by remember { mutableStateOf(initialTest?.duration?.toString() ?: "30") }
    var isActive by remember { mutableStateOf(initialTest?.is_active ?: true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (initialTest == null) LanguageStrings.get("add_test", currentLanguage) else LanguageStrings.get("edit_test", currentLanguage))
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(LanguageStrings.get("test_name", currentLanguage)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = durationStr,
                    onValueChange = { durationStr = it },
                    label = { Text("${LanguageStrings.get("duration", currentLanguage)} (${LanguageStrings.get("minutes", currentLanguage)})") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Checkbox(checked = isActive, onCheckedChange = { isActive = it })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(LanguageStrings.get("active", currentLanguage))
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val d = durationStr.toIntOrNull() ?: 30
                    if (name.isNotBlank()) {
                        onSave(name, d, isActive)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
            ) {
                Text(LanguageStrings.get("save", currentLanguage))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(LanguageStrings.get("cancel", currentLanguage))
            }
        }
    )
}

@Composable
fun AddEditQuestionDialog(
    initialQuestion: QuestionItem?,
    currentLanguage: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String, String, String, Int) -> Unit
) {
    var text by remember { mutableStateOf(initialQuestion?.question_text ?: "") }
    var optA by remember { mutableStateOf(initialQuestion?.option_a ?: "") }
    var optB by remember { mutableStateOf(initialQuestion?.option_b ?: "") }
    var optC by remember { mutableStateOf(initialQuestion?.option_c ?: "") }
    var optD by remember { mutableStateOf(initialQuestion?.option_d ?: "") }
    var correct by remember { mutableStateOf(initialQuestion?.correct_option ?: "A") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (initialQuestion == null) LanguageStrings.get("add_question", currentLanguage) else LanguageStrings.get("edit_question", currentLanguage))
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text(LanguageStrings.get("question_text", currentLanguage)) },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = optA,
                    onValueChange = { optA = it },
                    label = { Text(LanguageStrings.get("option_a", currentLanguage)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = optB,
                    onValueChange = { optB = it },
                    label = { Text(LanguageStrings.get("option_b", currentLanguage)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = optC,
                    onValueChange = { optC = it },
                    label = { Text(LanguageStrings.get("option_c", currentLanguage)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = optD,
                    onValueChange = { optD = it },
                    label = { Text(LanguageStrings.get("option_d", currentLanguage)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "${LanguageStrings.get("correct_option", currentLanguage)}:",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("A", "B", "C", "D").forEach { opt ->
                        FilterChip(
                            selected = correct == opt,
                            onClick = { correct = opt },
                            label = { Text(opt, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (text.isNotBlank() && optA.isNotBlank() && optB.isNotBlank() && optC.isNotBlank() && optD.isNotBlank()) {
                        onSave(text, optA, optB, optC, optD, correct, 1)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
            ) {
                Text(LanguageStrings.get("save", currentLanguage))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(LanguageStrings.get("cancel", currentLanguage))
            }
        }
    )
}

@Composable
fun AddUserDialog(
    currentLanguage: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (String, String, String, String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var mobile by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("Student") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(LanguageStrings.get("add_user", currentLanguage)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = mobile,
                    onValueChange = { mobile = it },
                    label = { Text(LanguageStrings.get("mobile", currentLanguage)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text(LanguageStrings.get("password", currentLanguage)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(text = "${LanguageStrings.get("role", currentLanguage)}:", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("Student", "Teacher", "Admin").forEach { r ->
                        FilterChip(
                            selected = role == r,
                            onClick = { role = r },
                            label = { Text(r) }
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && mobile.isNotBlank() && password.isNotBlank()) {
                        onSave(name, mobile, password, role)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue)
            ) {
                Text(LanguageStrings.get("save", currentLanguage))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(LanguageStrings.get("cancel", currentLanguage))
            }
        }
    )
}

@Composable
fun AddAnnouncementDialog(
    currentLanguage: AppLanguage,
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(LanguageStrings.get("create_announcement", currentLanguage)) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text(LanguageStrings.get("announcement_title", currentLanguage)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = message,
                    onValueChange = { message = it },
                    label = { Text(LanguageStrings.get("announcement_message", currentLanguage)) },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "💡 This announcement will automatically trigger a notification for all active students.",
                    style = MaterialTheme.typography.labelSmall,
                    color = PrimaryGreen
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank() && message.isNotBlank()) {
                        onSave(title, message)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
            ) {
                Text(LanguageStrings.get("save", currentLanguage))
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(LanguageStrings.get("cancel", currentLanguage))
            }
        }
    )
}

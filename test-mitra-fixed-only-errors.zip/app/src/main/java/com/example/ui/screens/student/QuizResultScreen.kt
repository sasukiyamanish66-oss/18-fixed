package com.example.ui.screens.student

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TestItem
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.QuizReviewItem
import com.example.ui.viewmodel.StudentViewModel
import com.example.util.AppLanguage
import com.example.util.LanguageStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizResultScreen(
    authViewModel: AuthViewModel,
    studentViewModel: StudentViewModel,
    onReattemptTest: (TestItem) -> Unit,
    onBackToHome: () -> Unit
) {
    val currentLanguage by authViewModel.currentLanguage.collectAsState()
    val result by studentViewModel.latestResult.collectAsState()
    val reviewItems by studentViewModel.reviewItems.collectAsState()
    val activeQuiz by studentViewModel.activeQuiz.collectAsState()

    val currentResult = result
    if (currentResult == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No result data available.")
        }
        return
    }

    val isPass = currentResult.percentage >= 50.0

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = LanguageStrings.get("test_result", currentLanguage),
                        fontWeight = FontWeight.Bold,
                        color = PrimaryBlue
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBackToHome,
                        modifier = Modifier.testTag("result_back_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PrimaryBlue)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            Surface(
                color = Color.White,
                tonalElevation = 8.dp,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val testItem = activeQuiz?.test
                    if (testItem != null) {
                        OutlinedButton(
                            onClick = {
                                studentViewModel.startTest(testItem) {
                                    onReattemptTest(testItem)
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.5.dp, PrimaryBlue),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryBlue),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp)
                                .testTag("reattempt_test_button")
                        ) {
                            Icon(Icons.Default.Replay, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = LanguageStrings.get("reattempt_test", currentLanguage),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Button(
                        onClick = onBackToHome,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("back_home_button")
                    ) {
                        Icon(Icons.Default.Home, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = LanguageStrings.get("back_to_home", currentLanguage),
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        },
        containerColor = AppBackgroundLight
    ) { innerPadding ->
        LazyColumn(
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("quiz_result_screen")
        ) {
            // Score Summary Card
            item {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isPass) PrimaryBlue else Color(0xFFDC2626)
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = Color.White.copy(alpha = 0.2f),
                            modifier = Modifier.padding(bottom = 8.dp)
                        ) {
                            Text(
                                text = currentResult.test_name ?: "Test",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Large Percentage Circle
                        Surface(
                            shape = CircleShape,
                            color = Color.White,
                            shadowElevation = 4.dp,
                            modifier = Modifier.size(124.dp)
                        ) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Text(
                                    text = "${currentResult.percentage.toInt()}%",
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = if (isPass) PrimaryGreen else ErrorRed
                                )
                                Text(
                                    text = if (isPass) "PASSED" else "NEEDS PRACTICE",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TextSecondary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        // Correct / Wrong / Unattempted Quick Badges
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceEvenly
                        ) {
                            ResultStatBadge(
                                label = LanguageStrings.get("correct", currentLanguage),
                                value = "${currentResult.correct_answers}",
                                icon = Icons.Default.CheckCircle,
                                color = Color(0xFFF0FDF4),
                                textColor = Color(0xFF16A34A)
                            )

                            ResultStatBadge(
                                label = LanguageStrings.get("wrong", currentLanguage),
                                value = "${currentResult.wrong_answers}",
                                icon = Icons.Default.Cancel,
                                color = Color(0xFFFEF2F2),
                                textColor = Color(0xFFDC2626)
                            )

                            ResultStatBadge(
                                label = LanguageStrings.get("unattempted", currentLanguage),
                                value = "${currentResult.unattempted}",
                                icon = Icons.Default.RemoveCircleOutline,
                                color = Color(0xFFF8FAFC),
                                textColor = Color(0xFF64748B)
                            )
                        }
                    }
                }
            }

            // Review Solutions Header
            item {
                Text(
                    text = LanguageStrings.get("review_answers", currentLanguage),
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = PrimaryBlue,
                    modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                )
            }

            // Question Reviews
            itemsIndexed(reviewItems) { index, item ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(
                        width = 1.dp,
                        color = when {
                            item.isCorrect -> SuccessGreen
                            item.isUnattempted -> AppBorderLight
                            else -> ErrorRed
                        }
                    ),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = when {
                                    item.isCorrect -> SecondaryContainerGreen
                                    item.isUnattempted -> AppSurfaceVariant
                                    else -> Color(0xFFFFEBEE)
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text(
                                        text = "Q${index + 1}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = when {
                                            item.isCorrect -> PrimaryGreen
                                            item.isUnattempted -> TextSecondary
                                            else -> ErrorRed
                                        }
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = when {
                                    item.isCorrect -> SecondaryContainerGreen
                                    item.isUnattempted -> AppSurfaceVariant
                                    else -> Color(0xFFFFEBEE)
                                }
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Icon(
                                        imageVector = when {
                                            item.isCorrect -> Icons.Default.CheckCircle
                                            item.isUnattempted -> Icons.Default.HelpOutline
                                            else -> Icons.Default.Cancel
                                        },
                                        contentDescription = null,
                                        tint = when {
                                            item.isCorrect -> PrimaryGreen
                                            item.isUnattempted -> TextSecondary
                                            else -> ErrorRed
                                        },
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = when {
                                            item.isCorrect -> LanguageStrings.get("correct", currentLanguage)
                                            item.isUnattempted -> LanguageStrings.get("unattempted", currentLanguage)
                                            else -> LanguageStrings.get("wrong", currentLanguage)
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = when {
                                            item.isCorrect -> OnSecondaryContainerGreen
                                            item.isUnattempted -> TextSecondary
                                            else -> ErrorRed
                                        }
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = item.question.question_text,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = TextPrimary
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        ReviewOptionRow(key = "A", text = item.question.option_a, item = item)
                        ReviewOptionRow(key = "B", text = item.question.option_b, item = item)
                        ReviewOptionRow(key = "C", text = item.question.option_c, item = item)
                        ReviewOptionRow(key = "D", text = item.question.option_d, item = item)
                    }
                }
            }
        }
    }
}

@Composable
fun ResultStatBadge(
    label: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    textColor: Color
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = color,
        modifier = Modifier.width(100.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(vertical = 10.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = textColor, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = textColor
            )
        }
    }
}

@Composable
fun ReviewOptionRow(
    key: String,
    text: String,
    item: QuizReviewItem
) {
    val isCorrectOption = key.equals(item.question.correct_option, ignoreCase = true)
    val isUserSelected = key.equals(item.selectedOption, ignoreCase = true)

    val bgColor = when {
        isCorrectOption -> Color(0xFFE8F5E9)
        isUserSelected && !isCorrectOption -> Color(0xFFFFEBEE)
        else -> AppSurfaceVariant.copy(alpha = 0.5f)
    }

    val textColor = when {
        isCorrectOption -> PrimaryGreen
        isUserSelected && !isCorrectOption -> ErrorRed
        else -> TextPrimary
    }

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bgColor,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "($key)",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = text,
                style = MaterialTheme.typography.bodySmall,
                color = textColor,
                modifier = Modifier.weight(1f)
            )
            if (isCorrectOption) {
                Text(
                    text = "✓ Correct",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = SuccessGreen
                )
            } else if (isUserSelected) {
                Text(
                    text = "✗ Your Answer",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = ErrorRed
                )
            }
        }
    }
}

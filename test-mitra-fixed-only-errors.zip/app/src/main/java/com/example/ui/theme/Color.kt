package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sleek Interface Blue Palette
val PrimaryBlue = Color(0xFF1D4ED8)          // Tailwind blue-700
val PrimaryBlueLight = Color(0xFF3B82F6)     // Tailwind blue-500
val PrimaryBlueDark = Color(0xFF1E3A8A)      // Tailwind blue-900
val PrimaryContainerBlue = Color(0xFFEFF6FF) // Tailwind blue-50
val OnPrimaryContainerBlue = Color(0xFF1E40AF)// Tailwind blue-800

// Sleek Emerald Green Palette (Accent / Live / Pass)
val PrimaryGreen = Color(0xFF059669)         // Tailwind emerald-600
val PrimaryGreenLight = Color(0xFF10B981)    // Tailwind emerald-500
val PrimaryGreenVibrant = Color(0xFF34D399)  // Tailwind emerald-400
val SecondaryContainerGreen = Color(0xFFECFDF5) // Tailwind emerald-50
val OnSecondaryContainerGreen = Color(0xFF065F46) // Tailwind emerald-800

// Dark Hero & Accents
val SleekNavyDark = Color(0xFF1E3A8A)        // Blue-900 for Hero Banner
val SleekSlateDark = Color(0xFF0F172A)       // Slate-900

// Neutral & Backgrounds (Sleek Slate Theme)
val AppBackgroundLight = Color(0xFFF1F5F9)   // Tailwind slate-100
val AppSurfaceLight = Color(0xFFFFFFFF)      // Pure White
val AppSurfaceVariant = Color(0xFFF8FAFC)    // Tailwind slate-50
val AppBorderLight = Color(0xFFE2E8F0)       // Tailwind slate-200
val AppBorderSubtle = Color(0xFFF1F5F9)

// Sleek Slate Typography
val TextPrimary = Color(0xFF0F172A)          // Tailwind slate-900
val TextSecondary = Color(0xFF64748B)        // Tailwind slate-500
val TextTertiary = Color(0xFF94A3B8)         // Tailwind slate-400

// Status Colors
val SuccessGreen = Color(0xFF10B981)         // Emerald-500
val ErrorRed = Color(0xFFEF4444)             // Red-500
val WarningAmber = Color(0xFFF59E0B)         // Amber-500
val WarningContainer = Color(0xFFFEF3C7)     // Amber-100
val WarningText = Color(0xFF92400E)          // Amber-800


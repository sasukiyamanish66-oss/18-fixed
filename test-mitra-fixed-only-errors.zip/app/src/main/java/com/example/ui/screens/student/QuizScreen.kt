package com.example.ui.screens.student

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.QuestionItem
import com.example.ui.theme.*
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.StudentViewModel
import com.example.util.AppLanguage
import com.example.util.LanguageStrings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuizScreen(
    authViewModel: AuthViewModel,
    studentViewModel: StudentViewModel,
    onQuizSubmitted: () -> Unit,
    onCancelQuiz: () -> Unit
) {
    val activeQuiz by studentViewModel.activeQuiz.collectAsState()
    val currentLanguage by authViewModel.currentLanguage.collectAsState()

    var showSubmitDialog by remember { mutableStateOf(false) }
    var showExitDialog by remember { mutableStateOf(false) }

    val quiz = activeQuiz
    if (quiz == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = PrimaryBlue)
        }
        return
    }

    val questions = quiz.questions
    val currentIndex = quiz.currentIndex
    val currentQuestion = questions.getOrNull(currentIndex)
    val selectedOption = currentQuestion?.let { quiz.selectedAnswers[it.id] }

    val minutes = quiz.remainingSeconds / 60
    val seconds = quiz.remainingSeconds % 60
    val timerString = String.format("%02d:%02d", minutes, seconds)
    val isTimerLow = quiz.remainingSeconds < 120 // < 2 mins

    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = quiz.test.test_name,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = PrimaryBlue,
                            maxLines = 1
                        )
                        Text(
                            text = "${LanguageStrings.get("questions", currentLanguage)} ${currentIndex + 1} / ${questions.size}",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { showExitDialog = true },
                        modifier = Modifier.testTag("quiz_close_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (isTimerLow) Color(0xFFFFEBEE) else PrimaryContainerBlue,
                        border = BorderStroke(1.dp, if (isTimerLow) ErrorRed else PrimaryBlueLight),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = "Timer",
                                tint = if (isTimerLow) ErrorRed else PrimaryBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = timerString,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isTimerLow) ErrorRed else PrimaryBlue
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            Surface(
                color = Color.White,
                tonalElevation = 8.dp,
                shadowElevation = 8.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = {
                            if (currentIndex > 0) {
                                studentViewModel.setCurrentQuestionIndex(currentIndex - 1)
                            }
                        },
                        enabled = currentIndex > 0,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.testTag("prev_question_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (currentLanguage == AppLanguage.GUJARATI) "પાછળ" else "Prev")
                    }

                    if (currentQuestion != null && selectedOption != null) {
                        TextButton(
                            onClick = { studentViewModel.clearAnswer(currentQuestion.id) },
                            modifier = Modifier.testTag("clear_answer_button")
                        ) {
                            Text(
                                text = if (currentLanguage == AppLanguage.GUJARATI) "રદ કરો" else "Clear",
                                color = TextSecondary,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }

                    if (currentIndex < questions.size - 1) {
                        Button(
                            onClick = { studentViewModel.setCurrentQuestionIndex(currentIndex + 1) },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryBlue),
                            modifier = Modifier.testTag("next_question_button")
                        ) {
                            Text(if (currentLanguage == AppLanguage.GUJARATI) "આગળ" else "Next")
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    } else {
                        Button(
                            onClick = { showSubmitDialog = true },
                            shape = RoundedCornerShape(10.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                            modifier = Modifier.testTag("submit_quiz_button")
                        ) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(LanguageStrings.get("submit_test", currentLanguage))
                        }
                    }
                }
            }
        },
        containerColor = AppBackgroundLight
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .testTag("quiz_screen")
        ) {
            // Question Palette (1..N)
            Surface(
                color = Color.White,
                modifier = Modifier.fillMaxWidth()
            ) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(questions) { index, q ->
                        val isAnswered = quiz.selectedAnswers.containsKey(q.id)
                        val isCurrent = index == currentIndex

                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(
                                    when {
                                        isCurrent -> PrimaryBlue
                                        isAnswered -> PrimaryGreen
                                        else -> AppSurfaceVariant
                                    }
                                )
                                .clickable { studentViewModel.setCurrentQuestionIndex(index) }
                                .testTag("palette_item_$index")
                        ) {
                            Text(
                                text = "${index + 1}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isCurrent || isAnswered) Color.White else TextPrimary
                            )
                        }
                    }
                }
            }

            if (currentQuestion != null) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(scrollState)
                        .padding(16.dp)
                ) {
                    // Question Card
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = PrimaryContainerBlue,
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = "Q${currentIndex + 1}",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = PrimaryBlue
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "${LanguageStrings.get("score", currentLanguage)}: ${currentQuestion.marks} Mark",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextSecondary
                                )
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = currentQuestion.question_text,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                lineHeight = 24.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = if (currentLanguage == AppLanguage.GUJARATI) "વિકલ્પ પસંદ કરો:" else "Select an option:",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = TextSecondary,
                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)
                    )

                    // Options A, B, C, D
                    QuizOptionItem(
                        optionKey = "A",
                        optionText = currentQuestion.option_a,
                        isSelected = selectedOption == "A",
                        onClick = { studentViewModel.selectAnswer(currentQuestion.id, "A") }
                    )

                    QuizOptionItem(
                        optionKey = "B",
                        optionText = currentQuestion.option_b,
                        isSelected = selectedOption == "B",
                        onClick = { studentViewModel.selectAnswer(currentQuestion.id, "B") }
                    )

                    QuizOptionItem(
                        optionKey = "C",
                        optionText = currentQuestion.option_c,
                        isSelected = selectedOption == "C",
                        onClick = { studentViewModel.selectAnswer(currentQuestion.id, "C") }
                    )

                    QuizOptionItem(
                        optionKey = "D",
                        optionText = currentQuestion.option_d,
                        isSelected = selectedOption == "D",
                        onClick = { studentViewModel.selectAnswer(currentQuestion.id, "D") }
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    // Direct Submit test button from anywhere
                    OutlinedButton(
                        onClick = { showSubmitDialog = true },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = PrimaryGreen),
                        border = BorderStroke(1.dp, PrimaryGreen),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.CheckCircleOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = LanguageStrings.get("submit_test", currentLanguage),
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }

    if (showSubmitDialog) {
        val answeredCount = quiz.selectedAnswers.size
        val unansweredCount = questions.size - answeredCount

        AlertDialog(
            onDismissRequest = { showSubmitDialog = false },
            title = { Text(LanguageStrings.get("submit_test", currentLanguage)) },
            text = {
                Column {
                    Text(LanguageStrings.get("submit_confirm", currentLanguage))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "✓ ${if (currentLanguage == AppLanguage.GUJARATI) "આપેલા જવાબો" else "Answered"}: $answeredCount",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = SuccessGreen
                    )
                    Text(
                        text = "• ${if (currentLanguage == AppLanguage.GUJARATI) "બાકી પ્રશ્નો" else "Unanswered"}: $unansweredCount",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = if (unansweredCount > 0) WarningAmber else TextSecondary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSubmitDialog = false
                        studentViewModel.submitQuiz(onComplete = onQuizSubmitted)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                    modifier = Modifier.testTag("confirm_submit_quiz_button")
                ) {
                    Text(LanguageStrings.get("submit_test", currentLanguage))
                }
            },
            dismissButton = {
                TextButton(onClick = { showSubmitDialog = false }) {
                    Text(LanguageStrings.get("cancel", currentLanguage))
                }
            }
        )
    }

    if (showExitDialog) {
        AlertDialog(
            onDismissRequest = { showExitDialog = false },
            title = { Text(if (currentLanguage == AppLanguage.GUJARATI) "પરીક્ષા છોડો?" else "Exit Quiz?") },
            text = { Text(if (currentLanguage == AppLanguage.GUJARATI) "જો તમે બહાર નીકળશો તો પરીક્ષા રદ થશે." else "Are you sure you want to leave? Your progress will not be saved.") },
            confirmButton = {
                Button(
                    onClick = {
                        showExitDialog = false
                        studentViewModel.clearActiveQuiz()
                        onCancelQuiz()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ErrorRed)
                ) {
                    Text(if (currentLanguage == AppLanguage.GUJARATI) "બહાર નીકળો" else "Exit")
                }
            },
            dismissButton = {
                TextButton(onClick = { showExitDialog = false }) {
                    Text(LanguageStrings.get("cancel", currentLanguage))
                }
            }
        )
    }
}

@Composable
fun QuizOptionItem(
    optionKey: String,
    optionText: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) PrimaryContainerBlue else Color.White
        ),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) PrimaryBlue else AppBorderLight
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 2.dp else 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
            .clickable(onClick = onClick)
            .testTag("option_$optionKey")
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = CircleShape,
                color = if (isSelected) PrimaryBlue else AppSurfaceVariant,
                modifier = Modifier.size(32.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(
                        text = optionKey,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) Color.White else TextPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Text(
                text = optionText,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                color = if (isSelected) PrimaryBlue else TextPrimary,
                modifier = Modifier.weight(1f)
            )

            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = PrimaryBlue,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

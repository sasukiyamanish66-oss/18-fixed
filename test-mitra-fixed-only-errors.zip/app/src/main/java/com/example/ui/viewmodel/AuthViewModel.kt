package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.User
import com.example.data.repository.OneDeviceLoginException
import com.example.data.repository.TestMitraRepository
import com.example.util.AppLanguage
import com.example.util.SessionManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed class AuthUiState {
    object Idle : AuthUiState()
    object Loading : AuthUiState()
    data class Authenticated(val user: User) : AuthUiState()
    data class Error(val message: String, val isOneDeviceError: Boolean = false) : AuthUiState()
}

class AuthViewModel(
    private val repository: TestMitraRepository,
    private val sessionManager: SessionManager,
    private val deviceId: String
) : ViewModel() {

    val currentUser: StateFlow<User?> = sessionManager.currentUser
    val currentLanguage: StateFlow<AppLanguage> = sessionManager.currentLanguage

    private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    fun checkExistingSession(onResult: (Boolean, User?) -> Unit) {
        viewModelScope.launch {
            val user = sessionManager.currentUser.value
            if (user != null) {
                val isValid = repository.validateActiveSession(deviceId)
                if (isValid) {
                    _uiState.value = AuthUiState.Authenticated(sessionManager.currentUser.value ?: user)
                    onResult(true, sessionManager.currentUser.value ?: user)
                } else {
                    _uiState.value = AuthUiState.Idle
                    onResult(false, null)
                }
            } else {
                _uiState.value = AuthUiState.Idle
                onResult(false, null)
            }
        }
    }

    fun login(mobile: String, pass: String) {
        if (mobile.isBlank() || pass.isBlank()) {
            _uiState.value = AuthUiState.Error("Please enter mobile number and password")
            return
        }

        viewModelScope.launch {
            _uiState.value = AuthUiState.Loading
            val result = repository.login(mobile, pass, deviceId)
            result.fold(
                onSuccess = { user ->
                    _uiState.value = AuthUiState.Authenticated(user)
                },
                onFailure = { error ->
                    if (error is OneDeviceLoginException) {
                        _uiState.value = AuthUiState.Error(
                            message = error.message ?: "આ એકાઉન્ટ બીજા ડિવાઇસમાં પહેલેથી Login છે.",
                            isOneDeviceError = true
                        )
                    } else if (error.message == "invalid_credentials") {
                        val isGu = currentLanguage.value == AppLanguage.GUJARATI
                        _uiState.value = AuthUiState.Error(
                            if (isGu) "ખોટો મોબાઇલ નંબર અથવા પાસવર્ડ." else "Invalid mobile number or password."
                        )
                    } else if (error.message == "account_inactive") {
                        val isGu = currentLanguage.value == AppLanguage.GUJARATI
                        _uiState.value = AuthUiState.Error(
                            if (isGu) "આ એકાઉન્ટ નિષ્ક્રિય છે. એડમિનનો સંપર્ક કરો." else "Account is deactivated. Contact Admin."
                        )
                    } else {
                        val isGu = currentLanguage.value == AppLanguage.GUJARATI
                        _uiState.value = AuthUiState.Error(
                            if (isGu) "કનેક્શન ત્રુટિ. ફરી પ્રયાસ કરો." else "Connection error. Please try again."
                        )
                    }
                }
            )
        }
    }

    fun logout(onLoggedOut: () -> Unit) {
        viewModelScope.launch {
            val user = sessionManager.currentUser.value
            if (user != null) {
                repository.logout(user.id)
            } else {
                sessionManager.clearSession()
            }
            _uiState.value = AuthUiState.Idle
            onLoggedOut()
        }
    }

    fun setLanguage(language: AppLanguage) {
        sessionManager.setLanguage(language)
    }

    fun clearError() {
        if (_uiState.value is AuthUiState.Error) {
            _uiState.value = AuthUiState.Idle
        }
    }
}

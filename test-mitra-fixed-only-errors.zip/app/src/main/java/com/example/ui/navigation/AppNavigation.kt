package com.example.ui.navigation

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.model.User
import com.example.ui.components.OfflineNoticeBanner
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.admin.AdminHomeScreen
import com.example.ui.screens.student.QuizResultScreen
import com.example.ui.screens.student.QuizScreen
import com.example.ui.screens.student.StudentHomeScreen
import com.example.ui.viewmodel.AdminViewModel
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.StudentViewModel
import com.example.util.NetworkMonitor

object AppRoutes {
    const val SPLASH = "splash"
    const val LOGIN = "login"
    const val STUDENT_HOME = "student_home"
    const val ADMIN_HOME = "admin_home"
    const val QUIZ = "quiz"
    const val QUIZ_RESULT = "quiz_result"
}

@Composable
fun AppNavigation(
    authViewModel: AuthViewModel,
    studentViewModel: StudentViewModel,
    adminViewModel: AdminViewModel,
    networkMonitor: NetworkMonitor,
    navController: NavHostController = rememberNavController()
) {
    val isOnline by networkMonitor.isOnline.collectAsState(initial = true)
    val currentLanguage by authViewModel.currentLanguage.collectAsState()
    val currentUser by authViewModel.currentUser.collectAsState()

    Scaffold(
        topBar = {
            OfflineNoticeBanner(
                isOnline = isOnline,
                currentLanguage = currentLanguage,
                onRetry = {
                    studentViewModel.loadActiveTests()
                    studentViewModel.loadAnnouncementsAndNotifications()
                    adminViewModel.loadTests()
                }
            )
        },
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = AppRoutes.SPLASH,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(AppRoutes.SPLASH) {
                SplashScreen(
                    authViewModel = authViewModel,
                    onNavigateToLogin = {
                        navController.navigate(AppRoutes.LOGIN) {
                            popUpTo(AppRoutes.SPLASH) { inclusive = true }
                        }
                    },
                    onNavigateToStudent = { _ ->
                        navController.navigate(AppRoutes.STUDENT_HOME) {
                            popUpTo(AppRoutes.SPLASH) { inclusive = true }
                        }
                    },
                    onNavigateToAdmin = { _ ->
                        navController.navigate(AppRoutes.ADMIN_HOME) {
                            popUpTo(AppRoutes.SPLASH) { inclusive = true }
                        }
                    }
                )
            }

            composable(AppRoutes.LOGIN) {
                LoginScreen(
                    authViewModel = authViewModel,
                    onLoginSuccess = { user ->
                        if (user.role.equals("Admin", ignoreCase = true) || user.role.equals("Teacher", ignoreCase = true)) {
                            navController.navigate(AppRoutes.ADMIN_HOME) {
                                popUpTo(AppRoutes.LOGIN) { inclusive = true }
                            }
                        } else {
                            navController.navigate(AppRoutes.STUDENT_HOME) {
                                popUpTo(AppRoutes.LOGIN) { inclusive = true }
                            }
                        }
                    }
                )
            }

            composable(AppRoutes.STUDENT_HOME) {
                val user = currentUser
                if (user != null) {
                    StudentHomeScreen(
                        user = user,
                        authViewModel = authViewModel,
                        studentViewModel = studentViewModel,
                        onStartTest = { testItem ->
                            studentViewModel.startTest(testItem) {
                                navController.navigate(AppRoutes.QUIZ)
                            }
                        },
                        onLogout = {
                            navController.navigate(AppRoutes.LOGIN) {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    )
                } else {
                    LaunchedEffect(Unit) {
                        navController.navigate(AppRoutes.LOGIN) {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                }
            }

            composable(AppRoutes.ADMIN_HOME) {
                val user = currentUser
                if (user != null) {
                    AdminHomeScreen(
                        user = user,
                        authViewModel = authViewModel,
                        adminViewModel = adminViewModel,
                        onLogout = {
                            navController.navigate(AppRoutes.LOGIN) {
                                popUpTo(0) { inclusive = true }
                            }
                        }
                    )
                } else {
                    LaunchedEffect(Unit) {
                        navController.navigate(AppRoutes.LOGIN) {
                            popUpTo(0) { inclusive = true }
                        }
                    }
                }
            }

            composable(AppRoutes.QUIZ) {
                QuizScreen(
                    authViewModel = authViewModel,
                    studentViewModel = studentViewModel,
                    onQuizSubmitted = {
                        navController.navigate(AppRoutes.QUIZ_RESULT) {
                            popUpTo(AppRoutes.QUIZ) { inclusive = true }
                        }
                    },
                    onCancelQuiz = {
                        navController.popBackStack()
                    }
                )
            }

            composable(AppRoutes.QUIZ_RESULT) {
                QuizResultScreen(
                    authViewModel = authViewModel,
                    studentViewModel = studentViewModel,
                    onReattemptTest = {
                        navController.navigate(AppRoutes.QUIZ) {
                            popUpTo(AppRoutes.QUIZ_RESULT) { inclusive = true }
                        }
                    },
                    onBackToHome = {
                        studentViewModel.clearActiveQuiz()
                        navController.navigate(AppRoutes.STUDENT_HOME) {
                            popUpTo(AppRoutes.STUDENT_HOME) { inclusive = false }
                        }
                    }
                )
            }
        }
    }
}

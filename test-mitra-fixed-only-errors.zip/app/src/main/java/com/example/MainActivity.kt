package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.data.repository.TestMitraRepository
import com.example.ui.navigation.AppNavigation
import com.example.ui.theme.TestMitraTheme
import com.example.ui.viewmodel.AdminViewModel
import com.example.ui.viewmodel.AuthViewModel
import com.example.ui.viewmodel.StudentViewModel
import com.example.util.DeviceUtil
import com.example.util.NetworkMonitor
import com.example.util.SessionManager

class MainActivity : ComponentActivity() {
    private lateinit var sessionManager: SessionManager
    private lateinit var repository: TestMitraRepository
    private lateinit var networkMonitor: NetworkMonitor
    private lateinit var authViewModel: AuthViewModel
    private lateinit var studentViewModel: StudentViewModel
    private lateinit var adminViewModel: AdminViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val deviceId = DeviceUtil.getDeviceId(this)
        sessionManager = SessionManager(this)
        repository = TestMitraRepository(sessionManager = sessionManager)
        networkMonitor = NetworkMonitor(this)

        authViewModel = AuthViewModel(repository, sessionManager, deviceId)
        studentViewModel = StudentViewModel(repository, sessionManager)
        adminViewModel = AdminViewModel(repository, sessionManager)

        setContent {
            TestMitraTheme {
                AppNavigation(
                    authViewModel = authViewModel,
                    studentViewModel = studentViewModel,
                    adminViewModel = adminViewModel,
                    networkMonitor = networkMonitor
                )
            }
        }
    }
}


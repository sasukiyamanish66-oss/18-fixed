package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class User(
    @Json(name = "id") val id: String,
    @Json(name = "name") val name: String,
    @Json(name = "mobile_number") val mobile_number: String,
    @Json(name = "password_hash") val password_hash: String,
    @Json(name = "role") val role: String, // "Student", "Teacher", "Admin"
    @Json(name = "is_active") val is_active: Boolean = true,
    @Json(name = "active_device_id") val active_device_id: String? = null,
    @Json(name = "active_session_token") val active_session_token: String? = null,
    @Json(name = "last_login_at") val last_login_at: String? = null,
    @Json(name = "created_at") val created_at: String? = null
)

@JsonClass(generateAdapter = true)
data class CreateUserRequest(
    @Json(name = "name") val name: String,
    @Json(name = "mobile_number") val mobile_number: String,
    @Json(name = "password_hash") val password_hash: String,
    @Json(name = "role") val role: String,
    @Json(name = "is_active") val is_active: Boolean = true
)

@JsonClass(generateAdapter = true)
data class UpdateUserSessionRequest(
    @Json(name = "active_device_id") val active_device_id: String?,
    @Json(name = "active_session_token") val active_session_token: String?,
    @Json(name = "last_login_at") val last_login_at: String? = null
)

@JsonClass(generateAdapter = true)
data class UpdateUserStatusRequest(
    @Json(name = "is_active") val is_active: Boolean
)

@JsonClass(generateAdapter = true)
data class TestItem(
    @Json(name = "id") val id: String,
    @Json(name = "test_name") val test_name: String,
    @Json(name = "duration") val duration: Int = 30, // in minutes
    @Json(name = "is_active") val is_active: Boolean = true,
    @Json(name = "created_at") val created_at: String? = null
)

@JsonClass(generateAdapter = true)
data class CreateTestRequest(
    @Json(name = "test_name") val test_name: String,
    @Json(name = "duration") val duration: Int,
    @Json(name = "is_active") val is_active: Boolean = true
)

@JsonClass(generateAdapter = true)
data class UpdateTestRequest(
    @Json(name = "test_name") val test_name: String? = null,
    @Json(name = "duration") val duration: Int? = null,
    @Json(name = "is_active") val is_active: Boolean? = null
)

@JsonClass(generateAdapter = true)
data class QuestionItem(
    @Json(name = "id") val id: String,
    @Json(name = "test_id") val test_id: String,
    @Json(name = "question_text") val question_text: String,
    @Json(name = "option_a") val option_a: String,
    @Json(name = "option_b") val option_b: String,
    @Json(name = "option_c") val option_c: String,
    @Json(name = "option_d") val option_d: String,
    @Json(name = "correct_option") val correct_option: String, // "A", "B", "C", "D"
    @Json(name = "marks") val marks: Int = 1,
    @Json(name = "created_at") val created_at: String? = null
)

@JsonClass(generateAdapter = true)
data class CreateQuestionRequest(
    @Json(name = "test_id") val test_id: String,
    @Json(name = "question_text") val question_text: String,
    @Json(name = "option_a") val option_a: String,
    @Json(name = "option_b") val option_b: String,
    @Json(name = "option_c") val option_c: String,
    @Json(name = "option_d") val option_d: String,
    @Json(name = "correct_option") val correct_option: String,
    @Json(name = "marks") val marks: Int = 1
)

@JsonClass(generateAdapter = true)
data class CreateQuestionRequestWithoutMarks(
    @Json(name = "test_id") val test_id: String,
    @Json(name = "question_text") val question_text: String,
    @Json(name = "option_a") val option_a: String,
    @Json(name = "option_b") val option_b: String,
    @Json(name = "option_c") val option_c: String,
    @Json(name = "option_d") val option_d: String,
    @Json(name = "correct_option") val correct_option: String
)

@JsonClass(generateAdapter = true)
data class UpdateQuestionRequest(
    @Json(name = "question_text") val question_text: String? = null,
    @Json(name = "option_a") val option_a: String? = null,
    @Json(name = "option_b") val option_b: String? = null,
    @Json(name = "option_c") val option_c: String? = null,
    @Json(name = "option_d") val option_d: String? = null,
    @Json(name = "correct_option") val correct_option: String? = null,
    @Json(name = "marks") val marks: Int? = null
)

@JsonClass(generateAdapter = true)
data class ResultItem(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val user_id: String,
    @Json(name = "test_id") val test_id: String,
    @Json(name = "total_questions") val total_questions: Int = 0,
    @Json(name = "correct_answers") val correct_answers: Int = 0,
    @Json(name = "wrong_answers") val wrong_answers: Int = 0,
    @Json(name = "unattempted") val unattempted: Int = 0,
    @Json(name = "percentage") val percentage: Double = 0.0,
    @Json(name = "attempt_number") val attempt_number: Int = 1,
    @Json(name = "submitted_at") val submitted_at: String,
    @Json(name = "created_at") val created_at: String? = null,
    // Extra client fields for enriched display
    @Transient val user_name: String? = null,
    @Transient val test_name: String? = null,
    @Transient val student_mobile: String? = null
)

@JsonClass(generateAdapter = true)
data class CreateResultRequest(
    @Json(name = "user_id") val user_id: String,
    @Json(name = "test_id") val test_id: String,
    @Json(name = "total_questions") val total_questions: Int,
    @Json(name = "correct_answers") val correct_answers: Int,
    @Json(name = "wrong_answers") val wrong_answers: Int,
    @Json(name = "unattempted") val unattempted: Int,
    @Json(name = "percentage") val percentage: Double,
    @Json(name = "attempt_number") val attempt_number: Int,
    @Json(name = "submitted_at") val submitted_at: String
)

@JsonClass(generateAdapter = true)
data class AnnouncementItem(
    @Json(name = "id") val id: String,
    @Json(name = "title") val title: String,
    @Json(name = "message") val message: String,
    @Json(name = "created_by") val created_by: String? = null,
    @Json(name = "is_active") val is_active: Boolean = true,
    @Json(name = "created_at") val created_at: String? = null
)

@JsonClass(generateAdapter = true)
data class CreateAnnouncementRequest(
    @Json(name = "title") val title: String,
    @Json(name = "message") val message: String,
    @Json(name = "created_by") val created_by: String? = null,
    @Json(name = "is_active") val is_active: Boolean = true
)

@JsonClass(generateAdapter = true)
data class NotificationItem(
    @Json(name = "id") val id: String,
    @Json(name = "user_id") val user_id: String,
    @Json(name = "announcement_id") val announcement_id: String? = null,
    @Json(name = "title") val title: String,
    @Json(name = "message") val message: String,
    @Json(name = "is_read") val is_read: Boolean = false,
    @Json(name = "created_at") val created_at: String? = null
)

@JsonClass(generateAdapter = true)
data class CreateNotificationRequest(
    @Json(name = "user_id") val user_id: String,
    @Json(name = "announcement_id") val announcement_id: String? = null,
    @Json(name = "title") val title: String,
    @Json(name = "message") val message: String,
    @Json(name = "is_read") val is_read: Boolean = false
)

@JsonClass(generateAdapter = true)
data class MarkNotificationReadRequest(
    @Json(name = "is_read") val is_read: Boolean = true
)

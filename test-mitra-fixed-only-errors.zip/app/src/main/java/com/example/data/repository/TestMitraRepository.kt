package com.example.data.repository

import com.example.data.api.SupabaseApi
import com.example.data.api.SupabaseClient
import com.example.data.model.*
import com.example.util.SessionManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.mindrot.jbcrypt.BCrypt
import java.text.SimpleDateFormat
import java.util.*

class OneDeviceLoginException(message: String) : Exception(message)

class TestMitraRepository(
    private val api: SupabaseApi = SupabaseClient.api,
    private val sessionManager: SessionManager
) {
    private val isoDateFormat = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US).apply {
        timeZone = TimeZone.getTimeZone("UTC")
    }

    private fun getCurrentIsoTime(): String = isoDateFormat.format(Date())

    // ---------------- AUTHENTICATION & SESSIONS ----------------
    suspend fun login(mobile: String, password: String, deviceId: String): Result<User> =
        withContext(Dispatchers.IO) {
            try {
                val cleanMobile = mobile.trim()
                val users = api.getUserByMobile(mobileNumberFilter = "eq.$cleanMobile")
                if (users.isEmpty()) {
                    return@withContext Result.failure(Exception("invalid_credentials"))
                }
                val user = users.first()

                // Check password with BCrypt
                val passwordValid = try {
                    BCrypt.checkpw(password, user.password_hash)
                } catch (e: Exception) {
                    false
                }

                if (!passwordValid) {
                    return@withContext Result.failure(Exception("invalid_credentials"))
                }

                if (!user.is_active) {
                    return@withContext Result.failure(Exception("account_inactive"))
                }

                // ONE DEVICE LOGIN ENFORCEMENT
                // If another device is currently active, prevent login and show exact Gujarati notice
                if (!user.active_device_id.isNullOrBlank() && user.active_device_id != deviceId) {
                    return@withContext Result.failure(
                        OneDeviceLoginException("આ એકાઉન્ટ બીજા ડિવાઇસમાં પહેલેથી Login છે.")
                    )
                }

                // Update DB with this device's active session
                val newSessionToken = UUID.randomUUID().toString()
                val nowTime = getCurrentIsoTime()

                val updatedUsers = api.updateUserSession(
                    idFilter = "eq.${user.id}",
                    body = UpdateUserSessionRequest(
                        active_device_id = deviceId,
                        active_session_token = newSessionToken,
                        last_login_at = nowTime
                    )
                )

                val activeUser = updatedUsers.firstOrNull() ?: user.copy(
                    active_device_id = deviceId,
                    active_session_token = newSessionToken,
                    last_login_at = nowTime
                )

                sessionManager.saveSession(activeUser, newSessionToken)
                Result.success(activeUser)
            } catch (e: OneDeviceLoginException) {
                Result.failure(e)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun validateActiveSession(deviceId: String): Boolean = withContext(Dispatchers.IO) {
        val savedUserId = sessionManager.getSavedUserId() ?: return@withContext false
        val savedToken = sessionManager.getSessionToken() ?: return@withContext false

        try {
            val users = api.getUserById(idFilter = "eq.$savedUserId")
            if (users.isEmpty()) {
                sessionManager.clearSession()
                return@withContext false
            }
            val user = users.first()
            if (!user.is_active || user.active_device_id != deviceId || user.active_session_token != savedToken) {
                sessionManager.clearSession()
                return@withContext false
            }
            sessionManager.saveSession(user, savedToken)
            true
        } catch (_: Exception) {
            // Keep local session if temporary network issue on splash
            true
        }
    }

    suspend fun logout(userId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            api.updateUserSession(
                idFilter = "eq.$userId",
                body = UpdateUserSessionRequest(
                    active_device_id = null,
                    active_session_token = null
                )
            )
            sessionManager.clearSession()
            Result.success(Unit)
        } catch (e: Exception) {
            // Still clear local session on logout
            sessionManager.clearSession()
            Result.success(Unit)
        }
    }

    // ---------------- USER MANAGEMENT (ADMIN) ----------------
    suspend fun getAllUsers(): Result<List<User>> = withContext(Dispatchers.IO) {
        try {
            val list = api.getAllUsers()
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createUser(name: String, mobile: String, rawPassword: String, role: String): Result<User> =
        withContext(Dispatchers.IO) {
            try {
                val cleanName = name.trim()
                val cleanMobile = mobile.trim().replace(Regex("\\s+"), "")
                val cleanPassword = rawPassword.trim()

                if (cleanName.isBlank()) return@withContext Result.failure(Exception("Name is required."))
                if (cleanMobile.isBlank()) return@withContext Result.failure(Exception("Mobile number is required."))
                if (cleanPassword.isBlank()) return@withContext Result.failure(Exception("Password is required."))

                // Avoid sending a duplicate mobile number to Supabase (HTTP 409).
                if (api.getUserByMobile(mobileNumberFilter = "eq.$cleanMobile").isNotEmpty()) {
                    return@withContext Result.failure(Exception("This mobile number is already registered. Please use another number."))
                }

                val hash = BCrypt.hashpw(cleanPassword, BCrypt.gensalt(10))
                val response = api.createUser(
                    CreateUserRequest(
                        name = cleanName,
                        mobile_number = cleanMobile,
                        password_hash = hash,
                        role = role,
                        is_active = true
                    )
                )
                if (!response.isSuccessful) {
                    val detail = response.errorBody()?.string()?.take(500).orEmpty()
                    return@withContext Result.failure(
                        Exception("HTTP ${response.code()} while creating user${if (detail.isNotBlank()) ": $detail" else "."}")
                    )
                }
                val user = response.body()?.firstOrNull()
                    ?: return@withContext Result.failure(Exception("User was created but no user data was returned."))
                Result.success(user)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun toggleUserStatus(userId: String, isActive: Boolean): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                api.updateUserStatus("eq.$userId", UpdateUserStatusRequest(is_active = isActive))
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun resetUserDevice(userId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            api.updateUserSession(
                idFilter = "eq.$userId",
                body = UpdateUserSessionRequest(
                    active_device_id = null,
                    active_session_token = null
                )
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteUser(userId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            api.deleteUser("eq.$userId")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- TESTS ----------------
    suspend fun getActiveTests(): Result<List<TestItem>> = withContext(Dispatchers.IO) {
        try {
            val tests = api.getActiveTests()
            Result.success(tests)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getAllTests(): Result<List<TestItem>> = withContext(Dispatchers.IO) {
        try {
            val tests = api.getTests()
            Result.success(tests)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createTest(name: String, durationMinutes: Int, isActive: Boolean): Result<TestItem> =
        withContext(Dispatchers.IO) {
            try {
                val tests = api.createTest(
                    CreateTestRequest(
                        test_name = name.trim(),
                        duration = durationMinutes,
                        is_active = isActive
                    )
                )
                Result.success(tests.first())
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun updateTest(testId: String, name: String, durationMinutes: Int, isActive: Boolean): Result<TestItem> =
        withContext(Dispatchers.IO) {
            try {
                val tests = api.updateTest(
                    idFilter = "eq.$testId",
                    request = UpdateTestRequest(
                        test_name = name.trim(),
                        duration = durationMinutes,
                        is_active = isActive
                    )
                )
                Result.success(tests.first())
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun toggleTestStatus(testId: String, isActive: Boolean): Result<TestItem> =
        withContext(Dispatchers.IO) {
            try {
                val tests = api.updateTest(
                    idFilter = "eq.$testId",
                    request = UpdateTestRequest(is_active = isActive)
                )
                if (tests.isNotEmpty()) {
                    Result.success(tests.first())
                } else {
                    Result.failure(Exception("Test not found"))
                }
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun deleteTest(testId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            // Delete questions for this test first to satisfy FK
            api.deleteQuestion("eq.$testId")
            api.deleteTest("eq.$testId")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- QUESTIONS ----------------
    suspend fun getQuestionsForTest(testId: String): Result<List<QuestionItem>> =
        withContext(Dispatchers.IO) {
            try {
                val questions = api.getQuestionsForTest(testIdFilter = "eq.$testId")
                Result.success(questions)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun createQuestion(
        testId: String,
        questionText: String,
        optionA: String,
        optionB: String,
        optionC: String,
        optionD: String,
        correctOption: String,
        marks: Int = 1
    ): Result<QuestionItem> = withContext(Dispatchers.IO) {
        try {
            val request = CreateQuestionRequest(
                test_id = testId.trim(),
                question_text = questionText.trim(),
                option_a = optionA.trim(),
                option_b = optionB.trim(),
                option_c = optionC.trim(),
                option_d = optionD.trim(),
                correct_option = correctOption.uppercase().trim(),
                marks = marks
            )

            var response = api.createQuestion(request)

            // Some existing TEST MITRA databases have no `marks` column.
            // If that is the exact Supabase 400, retry once without that field;
            // all other errors are returned unchanged.
            if (!response.isSuccessful && response.code() == 400) {
                val detail = response.errorBody()?.string().orEmpty()
                if (detail.contains("marks", ignoreCase = true)) {
                    response = api.createQuestion(
                        CreateQuestionRequestWithoutMarks(
                            test_id = request.test_id,
                            question_text = request.question_text,
                            option_a = request.option_a,
                            option_b = request.option_b,
                            option_c = request.option_c,
                            option_d = request.option_d,
                            correct_option = request.correct_option
                        )
                    )
                }
            }

            if (!response.isSuccessful) {
                val detail = response.errorBody()?.string()?.take(800).orEmpty()
                return@withContext Result.failure(
                    Exception("HTTP ${response.code()} while adding question${if (detail.isNotBlank()) ": $detail" else "."}")
                )
            }

            val question = response.body()?.firstOrNull()
                ?: return@withContext Result.failure(Exception("Question was saved but no question data was returned."))
            Result.success(question)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateQuestion(
        questionId: String,
        questionText: String,
        optionA: String,
        optionB: String,
        optionC: String,
        optionD: String,
        correctOption: String,
        marks: Int = 1
    ): Result<QuestionItem> = withContext(Dispatchers.IO) {
        try {
            val list = api.updateQuestion(
                idFilter = "eq.$questionId",
                request = UpdateQuestionRequest(
                    question_text = questionText.trim(),
                    option_a = optionA.trim(),
                    option_b = optionB.trim(),
                    option_c = optionC.trim(),
                    option_d = optionD.trim(),
                    correct_option = correctOption.uppercase().trim(),
                    marks = marks
                )
            )
            Result.success(list.first())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteQuestion(questionId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            api.deleteQuestion("eq.$questionId")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- RESULTS ----------------
    suspend fun submitQuizResult(
        userId: String,
        testId: String,
        totalQuestions: Int,
        correctAnswers: Int,
        wrongAnswers: Int,
        unattempted: Int,
        percentage: Double
    ): Result<ResultItem> = withContext(Dispatchers.IO) {
        try {
            // Determine attempt count for user on this test
            val prevResults = api.getResultsForUserAndTest(
                userIdFilter = "eq.$userId",
                testIdFilter = "eq.$testId"
            )
            val attemptNumber = prevResults.size + 1
            val nowTime = getCurrentIsoTime()

            val created = api.createResult(
                CreateResultRequest(
                    user_id = userId,
                    test_id = testId,
                    total_questions = totalQuestions,
                    correct_answers = correctAnswers,
                    wrong_answers = wrongAnswers,
                    unattempted = unattempted,
                    percentage = percentage,
                    attempt_number = attemptNumber,
                    submitted_at = nowTime
                )
            )
            Result.success(created.first())
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getUserResults(userId: String): Result<List<ResultItem>> =
        withContext(Dispatchers.IO) {
            try {
                val results = api.getResultsForUser(userIdFilter = "eq.$userId")
                val tests = api.getTests()
                val testsMap = tests.associateBy { it.id }

                val enriched = results.map { result ->
                    result.copy(
                        test_name = testsMap[result.test_id]?.test_name ?: "Test"
                    )
                }
                Result.success(enriched)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun getRecentAdminResults(): Result<List<ResultItem>> =
        withContext(Dispatchers.IO) {
            try {
                // Rule: Results must be visible in Admin Dashboard for only 5 hours after submission
                val fiveHoursAgo = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
                    add(Calendar.HOUR_OF_DAY, -5)
                }.time
                val fiveHoursAgoStr = isoDateFormat.format(fiveHoursAgo)

                val results = api.getRecentResultsSince(submittedAtFilter = "gte.$fiveHoursAgoStr")
                val users = api.getAllUsers()
                val tests = api.getTests()

                val usersMap = users.associateBy { it.id }
                val testsMap = tests.associateBy { it.id }

                val enriched = results.map { result ->
                    val user = usersMap[result.user_id]
                    result.copy(
                        user_name = user?.name ?: "Student",
                        student_mobile = user?.mobile_number,
                        test_name = testsMap[result.test_id]?.test_name ?: "Test"
                    )
                }
                Result.success(enriched)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    // ---------------- ANNOUNCEMENTS & NOTIFICATIONS ----------------
    suspend fun getAnnouncements(): Result<List<AnnouncementItem>> = withContext(Dispatchers.IO) {
        try {
            val list = api.getAnnouncements()
            Result.success(list)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createAnnouncement(title: String, message: String, createdBy: String?): Result<AnnouncementItem> =
        withContext(Dispatchers.IO) {
            try {
                val createdList = api.createAnnouncement(
                    CreateAnnouncementRequest(
                        title = title.trim(),
                        message = message.trim(),
                        created_by = createdBy,
                        is_active = true
                    )
                )
                val newAnnouncement = createdList.first()

                // Every new announcement creates a notification for active students
                val allUsers = api.getAllUsers()
                val activeStudents = allUsers.filter { it.role == "Student" && it.is_active }

                for (student in activeStudents) {
                    try {
                        api.createNotification(
                            CreateNotificationRequest(
                                user_id = student.id,
                                announcement_id = newAnnouncement.id,
                                title = title.trim(),
                                message = message.trim(),
                                is_read = false
                            )
                        )
                    } catch (_: Exception) {
                        // Keep going if a notification insert fails
                    }
                }

                Result.success(newAnnouncement)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun deleteAnnouncement(announcementId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            api.deleteAnnouncement("eq.$announcementId")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getNotificationsForUser(userId: String): Result<List<NotificationItem>> =
        withContext(Dispatchers.IO) {
            try {
                val list = api.getNotificationsForUser(userIdFilter = "eq.$userId")
                Result.success(list)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }

    suspend fun markNotificationRead(notificationId: String): Result<Unit> =
        withContext(Dispatchers.IO) {
            try {
                api.markNotificationRead("eq.$notificationId", MarkNotificationReadRequest(is_read = true))
                Result.success(Unit)
            } catch (e: Exception) {
                Result.failure(e)
            }
        }
}

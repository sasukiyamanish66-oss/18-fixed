package com.example.data.api

import com.example.data.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.*
import java.util.concurrent.TimeUnit

interface SupabaseApi {

    // ----------------- USERS -----------------
    @GET("users")
    suspend fun getUserByMobile(
        @Query("mobile_number") mobileNumberFilter: String = "",
        @Query("select") select: String = "*"
    ): List<User>

    @GET("users")
    suspend fun getUserById(
        @Query("id") idFilter: String,
        @Query("select") select: String = "*"
    ): List<User>

    @GET("users")
    suspend fun getAllUsers(
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc"
    ): List<User>

    @POST("users")
    suspend fun createUser(
        @Body request: CreateUserRequest
    ): Response<List<User>>

    @PATCH("users")
    suspend fun updateUserSession(
        @Query("id") idFilter: String,
        @Body body: UpdateUserSessionRequest
    ): List<User>

    @PATCH("users")
    suspend fun updateUserStatus(
        @Query("id") idFilter: String,
        @Body body: UpdateUserStatusRequest
    ): List<User>

    @DELETE("users")
    suspend fun deleteUser(
        @Query("id") idFilter: String
    ): Response<Unit>

    // ----------------- TESTS -----------------
    @GET("tests")
    suspend fun getTests(
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc"
    ): List<TestItem>

    @GET("tests")
    suspend fun getActiveTests(
        @Query("is_active") isActive: String = "eq.true",
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc"
    ): List<TestItem>

    @POST("tests")
    suspend fun createTest(
        @Body request: CreateTestRequest
    ): List<TestItem>

    @PATCH("tests")
    suspend fun updateTest(
        @Query("id") idFilter: String,
        @Body request: UpdateTestRequest
    ): List<TestItem>

    @DELETE("tests")
    suspend fun deleteTest(
        @Query("id") idFilter: String
    ): Response<Unit>

    // ----------------- QUESTIONS -----------------
    @GET("questions")
    suspend fun getQuestionsForTest(
        @Query("test_id") testIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.asc"
    ): List<QuestionItem>

    @POST("questions")
    suspend fun createQuestion(
        @Body request: CreateQuestionRequest
    ): Response<List<QuestionItem>>

    @PATCH("questions")
    suspend fun updateQuestion(
        @Query("id") idFilter: String,
        @Body request: UpdateQuestionRequest
    ): List<QuestionItem>

    @DELETE("questions")
    suspend fun deleteQuestion(
        @Query("id") idFilter: String
    ): Response<Unit>

    // ----------------- RESULTS -----------------
    @GET("results")
    suspend fun getResultsForUser(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "submitted_at.desc"
    ): List<ResultItem>

    @GET("results")
    suspend fun getResultsForUserAndTest(
        @Query("user_id") userIdFilter: String,
        @Query("test_id") testIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "attempt_number.desc"
    ): List<ResultItem>

    @GET("results")
    suspend fun getAllResults(
        @Query("select") select: String = "*",
        @Query("order") order: String = "submitted_at.desc"
    ): List<ResultItem>

    @GET("results")
    suspend fun getRecentResultsSince(
        @Query("submitted_at") submittedAtFilter: String, // e.g. "gte.2026-08-18T10:00:00Z"
        @Query("select") select: String = "*",
        @Query("order") order: String = "submitted_at.desc"
    ): List<ResultItem>

    @POST("results")
    suspend fun createResult(
        @Body request: CreateResultRequest
    ): List<ResultItem>

    // ----------------- ANNOUNCEMENTS -----------------
    @GET("announcements")
    suspend fun getAnnouncements(
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc"
    ): List<AnnouncementItem>

    @POST("announcements")
    suspend fun createAnnouncement(
        @Body request: CreateAnnouncementRequest
    ): List<AnnouncementItem>

    @DELETE("announcements")
    suspend fun deleteAnnouncement(
        @Query("id") idFilter: String
    ): Response<Unit>

    // ----------------- NOTIFICATIONS -----------------
    @GET("notifications")
    suspend fun getNotificationsForUser(
        @Query("user_id") userIdFilter: String,
        @Query("select") select: String = "*",
        @Query("order") order: String = "created_at.desc"
    ): List<NotificationItem>

    @POST("notifications")
    suspend fun createNotification(
        @Body request: CreateNotificationRequest
    ): List<NotificationItem>

    @PATCH("notifications")
    suspend fun markNotificationRead(
        @Query("id") idFilter: String,
        @Body request: MarkNotificationReadRequest
    ): List<NotificationItem>
}

object SupabaseClient {
    const val SUPABASE_URL = "https://orkqwjfyhvtwggtyvyqb.supabase.co"
    const val SUPABASE_PUBLISHABLE_KEY = "sb_publishable_vCngO32bdv_cjFV8u7RGsQ_BnAqgMsr"
    private const val REST_BASE_URL = "$SUPABASE_URL/rest/v1/"

    private val authInterceptor = Interceptor { chain ->
        val original = chain.request()
        val requestBuilder = original.newBuilder()
            .header("apikey", SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer $SUPABASE_PUBLISHABLE_KEY")
            .header("Content-Type", "application/json")
            .header("Prefer", "return=representation")
            .method(original.method, original.body)
        chain.proceed(requestBuilder.build())
    }

    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val okHttpClient: OkHttpClient = OkHttpClient.Builder()
        .addInterceptor(authInterceptor)
        .addInterceptor(loggingInterceptor)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    val api: SupabaseApi by lazy {
        Retrofit.Builder()
            .baseUrl(REST_BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create(moshi))
            .build()
            .create(SupabaseApi::class.java)
    }
}
